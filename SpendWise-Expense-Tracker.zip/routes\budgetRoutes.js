const express = require('express');
const router = express.Router();
const budgetController = require('../controllers/budgetController');
const { requireAuth } = require('../middleware/authMiddleware');

router.use(requireAuth);

router.get('/', budgetController.getBudgets);
router.get('/current', budgetController.getCurrentBudget);
router.post('/', budgetController.setBudget);
router.put('/:id', budgetController.updateBudget);
router.delete('/:id', budgetController.deleteBudget);

module.exports = router;

