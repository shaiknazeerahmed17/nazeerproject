const express = require('express');
const router = express.Router();
const reportController = require('../controllers/reportController');
const { requireAuth } = require('../middleware/authMiddleware');

router.use(requireAuth);

router.get('/monthly', reportController.getMonthlyReport);
router.get('/category-wise', reportController.getCategoryWiseReport);
router.get('/summary', reportController.getSummaryReport);

module.exports = router;

