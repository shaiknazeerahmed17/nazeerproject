const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');

/**
 * Get profile details and user metrics
 * GET /api/user/profile
 */
async function getProfile(req, res) {
    try {
        const userId = req.user.id;

        const [rows] = await pool.query(
            'SELECT id, name, email, DATE_FORMAT(created_at, "%Y-%m-%d %H:%i") AS member_since FROM users WHERE id = ?',
            [userId]
        );

        if (rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found.' });
        }

        const user = rows[0];

        // Fetch counts
        const [transCount] = await pool.query('SELECT COUNT(*) AS total FROM transactions WHERE user_id = ?', [userId]);
        const [catCount] = await pool.query('SELECT COUNT(*) AS total FROM categories WHERE user_id = ?', [userId]);
        const [budCount] = await pool.query('SELECT COUNT(*) AS total FROM budgets WHERE user_id = ?', [userId]);

        return res.json({
            success: true,
            user: {
                ...user,
                totalTransactions: transCount[0].total,
                totalCategories: catCount[0].total,
                totalBudgets: budCount[0].total
            }
        });
    } catch (error) {
        console.error('Get Profile Error:', error);
        return res.status(500).json({ success: false, message: 'Failed to retrieve profile.' });
    }
}

/**
 * Update user display name
 * PUT /api/user/profile
 */
async function updateProfile(req, res) {
    try {
        const userId = req.user.id;
        const { name } = req.body;

        if (!name || name.trim().length < 2) {
            return res.status(400).json({
                success: false,
                message: 'Name must be at least 2 characters long.'
            });
        }

        const trimmedName = name.trim();

        await pool.query('UPDATE users SET name = ? WHERE id = ?', [trimmedName, userId]);

        // Update session
        req.session.user.name = trimmedName;

        return res.json({
            success: true,
            message: 'Profile updated successfully.',
            user: {
                id: userId,
                name: trimmedName,
                email: req.session.user.email
            }
        });
    } catch (error) {
        console.error('Update Profile Error:', error);
        return res.status(500).json({ success: false, message: 'Failed to update profile.' });
    }
}

/**
 * Change user password
 * PUT /api/user/password
 */
async function changePassword(req, res) {
    try {
        const userId = req.user.id;
        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({
                success: false,
                message: 'Both current password and new password are required.'
            });
        }

        if (newPassword.length < 6) {
            return res.status(400).json({
                success: false,
                message: 'New password must be at least 6 characters long.'
            });
        }

        const [rows] = await pool.query('SELECT password FROM users WHERE id = ?', [userId]);
        if (rows.length === 0) {
            return res.status(404).json({ success: false, message: 'User not found.' });
        }

        const isMatch = await bcrypt.compare(currentPassword, rows[0].password);
        if (!isMatch) {
            return res.status(400).json({
                success: false,
                message: 'Incorrect current password.'
            });
        }

        const newHashed = await bcrypt.hash(newPassword, 10);
        await pool.query('UPDATE users SET password = ? WHERE id = ?', [newHashed, userId]);

        return res.json({
            success: true,
            message: 'Password changed successfully.'
        });
    } catch (error) {
        console.error('Change Password Error:', error);
        return res.status(500).json({ success: false, message: 'Failed to change password.' });
    }
}

module.exports = {
    getProfile,
    updateProfile,
    changePassword
};

