/**
 * SpendWise - User Profile & Security Controller
 */

document.addEventListener('DOMContentLoaded', async () => {
    const user = await checkAuthAndSetUser();
    if (!user) return;

    await loadUserProfile();
    setupUpdateProfileForm();
    setupChangePasswordForm();
});

/**
 * Load user profile & usage statistics
 */
async function loadUserProfile() {
    try {
        const data = await API.get('/api/user/profile');
        if (!data.success) throw new Error(data.message);

        const u = data.user;

        const nameInput = document.getElementById('profileName');
        const emailInput = document.getElementById('profileEmail');
        const joinedDateEl = document.getElementById('profileJoinedDate');
        const countTransEl = document.getElementById('profileStatTransactions');
        const countCatsEl = document.getElementById('profileStatCategories');
        const countBudgetsEl = document.getElementById('profileStatBudgets');

        if (nameInput) nameInput.value = u.name;
        if (emailInput) emailInput.value = u.email;
        if (joinedDateEl) joinedDateEl.textContent = u.member_since || 'Active Member';
        if (countTransEl) countTransEl.textContent = u.totalTransactions || 0;
        if (countCatsEl) countCatsEl.textContent = u.totalCategories || 0;
        if (countBudgetsEl) countBudgetsEl.textContent = u.totalBudgets || 0;

    } catch (e) {
        console.error('Failed to load profile:', e);
        showToast('Error loading profile details', 'error');
    }
}

/**
 * Handle display name update
 */
function setupUpdateProfileForm() {
    const form = document.getElementById('updateProfileForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const name = document.getElementById('profileName').value.trim();
        const submitBtn = form.querySelector('button[type="submit"]');

        if (!name || name.length < 2) {
            showToast('Full name must be at least 2 characters long.', 'warning');
            return;
        }

        try {
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';
            }

            const res = await API.put('/api/user/profile', { name });

            if (res.success) {
                showToast('Profile updated successfully!', 'success');
                await checkAuthAndSetUser(); // Refresh names in sidebar/header
            }
        } catch (err) {
            showToast(err.message || 'Failed to update profile', 'error');
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Save Profile';
            }
        }
    });
}

/**
 * Handle password change
 */
function setupChangePasswordForm() {
    const form = document.getElementById('changePasswordForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const currentPassword = document.getElementById('currentPassword').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmNewPassword = document.getElementById('confirmNewPassword').value;
        const submitBtn = form.querySelector('button[type="submit"]');

        if (!currentPassword || !newPassword || !confirmNewPassword) {
            showToast('Please fill in all password fields.', 'warning');
            return;
        }

        if (newPassword.length < 6) {
            showToast('New password must be at least 6 characters.', 'warning');
            return;
        }

        if (newPassword !== confirmNewPassword) {
            showToast('New passwords do not match.', 'error');
            return;
        }

        try {
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Updating...';
            }

            const res = await API.put('/api/user/password', {
                currentPassword,
                newPassword
            });

            if (res.success) {
                showToast('Password updated successfully!', 'success');
                form.reset();
            }
        } catch (err) {
            showToast(err.message || 'Failed to change password', 'error');
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fa-solid fa-key"></i> Update Password';
            }
        }
    });
}

