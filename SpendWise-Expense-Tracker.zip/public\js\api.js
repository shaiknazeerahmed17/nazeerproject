/**
 * SpendWise - Frontend Core API Client & Utilities
 */

const API = {
    /**
     * Centralized fetch wrapper
     */
    async request(endpoint, options = {}) {
        const defaultHeaders = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };

        const config = {
            ...options,
            headers: {
                ...defaultHeaders,
                ...options.headers
            }
        };

        try {
            const response = await fetch(endpoint, config);

            // Handle unauthorized access on protected routes
            if (response.status === 401) {
                const isAuthPage = window.location.pathname.includes('login') ||
                                   window.location.pathname.includes('register') ||
                                   window.location.pathname === '/' ||
                                   window.location.pathname.includes('index');
                if (!isAuthPage) {
                    window.location.href = '/login.html';
                }
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || 'Session expired. Please log in.');
            }

            const data = await response.json().catch(() => ({}));

            if (!response.ok) {
                throw new Error(data.message || `Request failed with status ${response.status}`);
            }

            return data;
        } catch (error) {
            console.error(`API Error on [${endpoint}]:`, error);
            throw error;
        }
    },

    get(endpoint) {
        return this.request(endpoint, { method: 'GET' });
    },

    post(endpoint, body) {
        return this.request(endpoint, {
            method: 'POST',
            body: JSON.stringify(body)
        });
    },

    put(endpoint, body) {
        return this.request(endpoint, {
            method: 'PUT',
            body: JSON.stringify(body)
        });
    },

    delete(endpoint) {
        return this.request(endpoint, { method: 'DELETE' });
    }
};

/**
 * Toast Notification System
 */
function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    let iconClass = 'fa-info-circle';
    if (type === 'success') iconClass = 'fa-check-circle';
    if (type === 'error') iconClass = 'fa-exclamation-circle';
    if (type === 'warning') iconClass = 'fa-triangle-exclamation';

    toast.innerHTML = `
        <i class="fa-solid ${iconClass}"></i>
        <div style="flex: 1;">${message}</div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

/**
 * Currency Formatter
 */
function formatCurrency(amount) {
    const num = Number(amount) || 0;
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(num);
}

/**
 * Date Formatter
 */
function formatDate(dateStr) {
    if (!dateStr) return 'N/A';
    const parts = dateStr.split('-');
    if (parts.length === 3) {
        const year = parts[0];
        const monthIndex = parseInt(parts[1], 10) - 1;
        const day = parts[2];
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return `${monthNames[monthIndex]} ${day}, ${year}`;
    }
    return dateStr;
}

/**
 * Session verification and user details populate
 */
async function checkAuthAndSetUser() {
    try {
        const data = await API.get('/api/auth/me');
        if (data.success && data.user) {
            // Update sidebar & header user elements
            const userNameEls = document.querySelectorAll('.user-display-name');
            const userEmailEls = document.querySelectorAll('.user-display-email');
            const userAvatarEls = document.querySelectorAll('.user-avatar-initials');

            userNameEls.forEach(el => el.textContent = data.user.name);
            userEmailEls.forEach(el => el.textContent = data.user.email);
            userAvatarEls.forEach(el => {
                const initials = data.user.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
                el.textContent = initials || 'U';
            });
            return data.user;
        }
    } catch (err) {
        console.warn('Authentication check failed:', err.message);
    }
    return null;
}

/**
 * Global Logout Handler
 */
async function handleLogout() {
    try {
        await API.post('/api/auth/logout');
        showToast('Logged out successfully', 'success');
        setTimeout(() => {
            window.location.href = '/login.html';
        }, 500);
    } catch (err) {
        showToast('Logout error: ' + err.message, 'error');
    }
}

/**
 * Initialize Sidebar and Mobile Drawer
 */
function initSidebar() {
    const mobileBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.querySelector('.sidebar');
    let overlay = document.querySelector('.sidebar-overlay');

    if (!overlay && sidebar) {
        overlay = document.createElement('div');
        overlay.className = 'sidebar-overlay';
        document.body.appendChild(overlay);
    }

    if (mobileBtn && sidebar) {
        mobileBtn.addEventListener('click', () => {
            sidebar.classList.toggle('open');
            if (overlay) overlay.classList.toggle('active');
        });
    }

    if (overlay && sidebar) {
        overlay.addEventListener('click', () => {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
        });
    }

    // Attach logout buttons
    document.querySelectorAll('.btn-logout').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            handleLogout();
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    initSidebar();
});

