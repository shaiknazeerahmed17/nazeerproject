/**
 * SpendWise - Dashboard Controller & Interactive Charts
 */

let monthlyTrendChartInstance = null;
let categoryDoughnutChartInstance = null;
let userCategories = [];

document.addEventListener('DOMContentLoaded', async () => {
    const user = await checkAuthAndSetUser();
    if (!user) return;

    // Load Dashboard Analytics & Charts
    await loadDashboardData();

    // Load Categories for the Quick Add modal
    await loadCategories();

    // Setup Quick Add Modal & Event Listeners
    setupQuickAddModal();
});

/**
 * Load Dashboard Analytics from Backend
 */
async function loadDashboardData() {
    try {
        const data = await API.get('/api/dashboard');
        if (!data.success) throw new Error(data.message);

        // Update KPI metrics
        const totalIncomeEl = document.getElementById('metricTotalIncome');
        const totalExpenseEl = document.getElementById('metricTotalExpense');
        const currentBalanceEl = document.getElementById('metricCurrentBalance');
        const budgetAmountEl = document.getElementById('metricBudgetAmount');
        const budgetRemainingEl = document.getElementById('metricBudgetRemaining');
        const budgetPercentageEl = document.getElementById('metricBudgetPercentage');
        const budgetProgressFillEl = document.getElementById('budgetProgressFill');
        const budgetStatusBadgeEl = document.getElementById('budgetStatusBadge');

        if (totalIncomeEl) totalIncomeEl.textContent = formatCurrency(data.summary.totalIncome);
        if (totalExpenseEl) totalExpenseEl.textContent = formatCurrency(data.summary.totalExpenses);
        
        if (currentBalanceEl) {
            currentBalanceEl.textContent = formatCurrency(data.summary.currentBalance);
            if (data.summary.currentBalance < 0) {
                currentBalanceEl.style.color = 'var(--danger)';
            } else {
                currentBalanceEl.style.color = 'var(--navy-900)';
            }
        }

        // Budget Widget
        const b = data.budget;
        if (budgetAmountEl) {
            if (b.hasBudget) {
                budgetAmountEl.textContent = formatCurrency(b.budget_amount);
                if (budgetRemainingEl) budgetRemainingEl.textContent = `${formatCurrency(b.remaining)} remaining`;
                if (budgetPercentageEl) budgetPercentageEl.textContent = `${b.percentage}% spent`;
                
                if (budgetProgressFillEl) {
                    const widthVal = Math.min(b.percentage, 100);
                    budgetProgressFillEl.style.width = `${widthVal}%`;
                    budgetProgressFillEl.className = `progress-bar-fill ${b.status}`;
                }

                if (budgetStatusBadgeEl) {
                    budgetStatusBadgeEl.style.display = 'inline-flex';
                    if (b.status === 'exceeded') {
                        budgetStatusBadgeEl.className = 'badge badge-expense';
                        budgetStatusBadgeEl.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> Budget Exceeded';
                    } else if (b.status === 'warning') {
                        budgetStatusBadgeEl.className = 'badge badge-warning';
                        budgetStatusBadgeEl.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> Near Limit (80%+)';
                    } else {
                        budgetStatusBadgeEl.className = 'badge badge-income';
                        budgetStatusBadgeEl.innerHTML = '<i class="fa-solid fa-circle-check"></i> On Track';
                    }
                }
            } else {
                budgetAmountEl.textContent = 'Not Set';
                if (budgetRemainingEl) budgetRemainingEl.textContent = `${formatCurrency(b.spent)} spent this month`;
                if (budgetPercentageEl) budgetPercentageEl.textContent = 'Set a monthly budget to track';
                if (budgetProgressFillEl) budgetProgressFillEl.style.width = '0%';
                if (budgetStatusBadgeEl) budgetStatusBadgeEl.style.display = 'none';
            }
        }

        // Render Charts
        renderMonthlyTrendChart(data.charts.monthlyTrend);
        renderCategoryDoughnutChart(data.charts.categoryBreakdown);

        // Render Recent Transactions
        renderRecentTransactions(data.recentTransactions);

    } catch (error) {
        console.error('Error loading dashboard data:', error);
        showToast('Failed to load dashboard metrics.', 'error');
    }
}

/**
 * Render Monthly Income vs Expense Chart (Bar Chart)
 */
function renderMonthlyTrendChart(trendData) {
    const ctx = document.getElementById('monthlyTrendChart');
    if (!ctx) return;

    if (monthlyTrendChartInstance) {
        monthlyTrendChartInstance.destroy();
    }

    const labels = trendData.length > 0 ? trendData.map(d => d.label) : ['No Data'];
    const incomeData = trendData.length > 0 ? trendData.map(d => d.income) : [0];
    const expenseData = trendData.length > 0 ? trendData.map(d => d.expense) : [0];

    monthlyTrendChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels,
            datasets: [
                {
                    label: 'Income',
                    data: incomeData,
                    backgroundColor: 'rgba(16, 185, 129, 0.85)',
                    borderColor: '#10b981',
                    borderRadius: 6,
                    borderWidth: 1,
                    maxBarThickness: 32
                },
                {
                    label: 'Expense',
                    data: expenseData,
                    backgroundColor: 'rgba(239, 68, 68, 0.85)',
                    borderColor: '#ef4444',
                    borderRadius: 6,
                    borderWidth: 1,
                    maxBarThickness: 32
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        boxWidth: 14,
                        font: { family: 'Inter', size: 12, weight: 500 }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${formatCurrency(context.raw)}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: { display: false }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: (value) => `$${value}`
                    },
                    grid: {
                        color: 'rgba(226, 232, 240, 0.6)'
                    }
                }
            }
        }
    });
}

/**
 * Render Category Breakdown Chart (Doughnut Chart)
 */
function renderCategoryDoughnutChart(breakdownData) {
    const ctx = document.getElementById('categoryDoughnutChart');
    const emptyNotice = document.getElementById('categoryChartEmpty');
    if (!ctx) return;

    if (categoryDoughnutChartInstance) {
        categoryDoughnutChartInstance.destroy();
    }

    if (!breakdownData || breakdownData.length === 0) {
        ctx.style.display = 'none';
        if (emptyNotice) emptyNotice.style.display = 'flex';
        return;
    } else {
        ctx.style.display = 'block';
        if (emptyNotice) emptyNotice.style.display = 'none';
    }

    const labels = breakdownData.map(d => d.category_name);
    const data = breakdownData.map(d => d.total_amount);

    const colors = [
        '#3b82f6', '#10b981', '#f59e0b', '#ec4899',
        '#8b5cf6', '#14b8a6', '#f97316', '#64748b'
    ];

    categoryDoughnutChartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels,
            datasets: [{
                data,
                backgroundColor: colors.slice(0, data.length),
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '68%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 12,
                        padding: 12,
                        font: { family: 'Inter', size: 11 }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.raw || 0;
                            return ` ${context.label}: ${formatCurrency(value)}`;
                        }
                    }
                }
            }
        }
    });
}

/**
 * Render Recent Transactions Table
 */
function renderRecentTransactions(transactions) {
    const tbody = document.getElementById('recentTransactionsBody');
    const emptyEl = document.getElementById('recentTransactionsEmpty');
    if (!tbody) return;

    tbody.innerHTML = '';

    if (!transactions || transactions.length === 0) {
        if (emptyEl) emptyEl.style.display = 'block';
        return;
    } else {
        if (emptyEl) emptyEl.style.display = 'none';
    }

    transactions.forEach(t => {
        const isIncome = t.transaction_type === 'Income';
        const sign = isIncome ? '+' : '-';
        const amountClass = isIncome ? 'amount-income' : 'amount-expense';
        const badgeClass = isIncome ? 'badge-income' : 'badge-expense';

        const row = document.createElement('tr');
        row.innerHTML = `
            <td class="tabular-nums" style="font-weight: 500;">${formatDate(t.transaction_date)}</td>
            <td>
                <span class="badge ${badgeClass}">
                    <i class="fa-solid ${isIncome ? 'fa-arrow-down-left' : 'fa-arrow-up-right'}"></i>
                    ${t.transaction_type}
                </span>
            </td>
            <td><span class="badge badge-neutral">${t.category_name || 'General'}</span></td>
            <td style="color: var(--text-secondary); max-width: 250px; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;">
                ${t.description || '—'}
            </td>
            <td class="${amountClass} tabular-nums" style="text-align: right; font-size: 0.95rem;">
                ${sign}${formatCurrency(t.amount)}
            </td>
        `;
        tbody.appendChild(row);
    });
}

/**
 * Load Categories for Modals
 */
async function loadCategories() {
    try {
        const res = await API.get('/api/categories');
        if (res.success) {
            userCategories = res.categories || [];
            updateCategoryDropdown('Expense'); // default selection
        }
    } catch (e) {
        console.error('Failed to load categories for modal:', e);
    }
}

/**
 * Update Category Dropdown filtered by transaction type
 */
function updateCategoryDropdown(selectedType) {
    const catSelect = document.getElementById('quickAddCategory');
    if (!catSelect) return;

    catSelect.innerHTML = '<option value="">Select Category</option>';

    const filtered = userCategories.filter(c => c.category_type === selectedType);
    filtered.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c.category_id;
        opt.textContent = c.category_name;
        catSelect.appendChild(opt);
    });
}

/**
 * Setup Quick Add Transaction Modal
 */
function setupQuickAddModal() {
    const modal = document.getElementById('quickAddModal');
    const openBtns = document.querySelectorAll('.btn-open-quick-add');
    const closeBtn = document.getElementById('closeQuickAddBtn');
    const cancelBtn = document.getElementById('cancelQuickAddBtn');
    const form = document.getElementById('quickAddForm');
    const typeSelect = document.getElementById('quickAddType');
    const dateInput = document.getElementById('quickAddDate');

    if (dateInput) {
        dateInput.value = new Date().toISOString().split('T')[0];
    }

    if (typeSelect) {
        typeSelect.addEventListener('change', (e) => {
            updateCategoryDropdown(e.target.value);
        });
    }

    openBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            if (modal) modal.classList.add('active');
        });
    });

    const closeModal = () => {
        if (modal) modal.classList.remove('active');
        if (form) form.reset();
        if (dateInput) dateInput.value = new Date().toISOString().split('T')[0];
        updateCategoryDropdown('Expense');
    };

    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);

    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const amount = document.getElementById('quickAddAmount').value;
            const transaction_type = document.getElementById('quickAddType').value;
            const category_id = document.getElementById('quickAddCategory').value;
            const transaction_date = document.getElementById('quickAddDate').value;
            const description = document.getElementById('quickAddDescription').value;

            if (!amount || parseFloat(amount) <= 0) {
                showToast('Please enter a valid amount greater than 0', 'warning');
                return;
            }

            try {
                const res = await API.post('/api/transactions', {
                    amount,
                    transaction_type,
                    category_id: category_id || null,
                    transaction_date,
                    description
                });

                if (res.success) {
                    showToast('Transaction recorded successfully!', 'success');
                    closeModal();
                    await loadDashboardData(); // Refresh UI
                }
            } catch (err) {
                showToast(err.message || 'Failed to add transaction', 'error');
            }
        });
    }
}

