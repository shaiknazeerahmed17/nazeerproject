const { pool, initializeDatabase } = require('../config/db');
const fs = require('fs');
const path = require('path');

async function runSeed() {
    try {
        console.log('🚀 Initializing database schema...');
        await initializeDatabase();

        const schemaFile = path.join(__dirname, 'schema.sql');
        const sampleFile = path.join(__dirname, 'sample_data.sql');

        if (fs.existsSync(sampleFile)) {
            console.log('🌱 Populating sample data from sample_data.sql...');
            const sampleSql = fs.readFileSync(sampleFile, 'utf8');
            // Split by semicolon ignoring comments
            const statements = sampleSql
                .replace(/--.*$/gm, '')
                .split(';')
                .map(s => s.trim())
                .filter(s => s.length > 0);

            for (const statement of statements) {
                if (statement.toLowerCase().startsWith('use ')) continue;
                await pool.query(statement);
            }
            console.log('✅ Sample data loaded successfully!');
            console.log('👤 Demo User: demo@expensetracker.com | Password: password123');
        }

        process.exit(0);
    } catch (err) {
        console.error('❌ Error initializing database:', err);
        process.exit(1);
    }
}

runSeed();

