/**
 * SpendWise - Authentication Scripts (Login & Register)
 */

document.addEventListener('DOMContentLoaded', () => {
    // ----------------------------------------------------
    // LOGIN FORM HANDLING
    // ----------------------------------------------------
    const loginForm = document.getElementById('loginForm');
    const demoFillBtn = document.getElementById('demoFillBtn');

    if (demoFillBtn) {
        demoFillBtn.addEventListener('click', () => {
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');
            if (emailInput && passwordInput) {
                emailInput.value = 'demo@expensetracker.com';
                passwordInput.value = 'password123';
                showToast('Demo credentials populated!', 'info');
            }
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const submitBtn = loginForm.querySelector('button[type="submit"]');

            if (!email || !password) {
                showToast('Please enter both email and password.', 'warning');
                return;
            }

            try {
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Signing in...';
                }

                const response = await API.post('/api/auth/login', { email, password });

                if (response.success) {
                    showToast('Login successful! Redirecting...', 'success');
                    setTimeout(() => {
                        window.location.href = '/dashboard.html';
                    }, 600);
                }
            } catch (error) {
                showToast(error.message || 'Login failed. Please check your credentials.', 'error');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<i class="fa-solid fa-right-to-bracket"></i> Sign In';
                }
            }
        });
    }

    // ----------------------------------------------------
    // REGISTER FORM HANDLING
    // ----------------------------------------------------
    const registerForm = document.getElementById('registerForm');

    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const submitBtn = registerForm.querySelector('button[type="submit"]');

            // Form Validations
            if (!name || !email || !password || !confirmPassword) {
                showToast('Please fill in all required fields.', 'warning');
                return;
            }

            if (name.length < 2) {
                showToast('Full name must be at least 2 characters.', 'warning');
                return;
            }

            if (password.length < 6) {
                showToast('Password must be at least 6 characters long.', 'warning');
                return;
            }

            if (password !== confirmPassword) {
                showToast('Passwords do not match. Please re-enter.', 'error');
                return;
            }

            try {
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Creating Account...';
                }

                const response = await API.post('/api/auth/register', { name, email, password });

                if (response.success) {
                    showToast('Account created successfully! Welcome to SpendWise.', 'success');
                    setTimeout(() => {
                        window.location.href = '/dashboard.html';
                    }, 800);
                }
            } catch (error) {
                showToast(error.message || 'Registration failed.', 'error');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<i class="fa-solid fa-user-plus"></i> Create Account';
                }
            }
        });
    }
});

