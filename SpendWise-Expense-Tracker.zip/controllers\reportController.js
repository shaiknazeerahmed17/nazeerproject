const { pool } = require('../config/db');

const MONTH_NAMES = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

/**
 * Get comprehensive dashboard analytics
 * GET /api/dashboard
 */
async function getDashboardData(req, res) {
    try {
        const userId = req.user.id;
        const now = new Date();
        const currentMonth = now.getMonth() + 1;
        const currentYear = now.getFullYear();

        // 1. Overall Lifetime Totals
        const [overallTotals] = await pool.query(
            `SELECT 
                COALESCE(SUM(CASE WHEN transaction_type = 'Income' THEN amount ELSE 0 END), 0) AS total_income,
                COALESCE(SUM(CASE WHEN transaction_type = 'Expense' THEN amount ELSE 0 END), 0) AS total_expenses,
                COUNT(*) AS total_transactions
            FROM transactions 
            WHERE user_id = ?`,
            [userId]
        );

        const totalIncome = Number(overallTotals[0].total_income);
        const totalExpenses = Number(overallTotals[0].total_expenses);
        const currentBalance = totalIncome - totalExpenses;

        // 2. This Month Totals
        const [monthTotals] = await pool.query(
            `SELECT 
                COALESCE(SUM(CASE WHEN transaction_type = 'Income' THEN amount ELSE 0 END), 0) AS month_income,
                COALESCE(SUM(CASE WHEN transaction_type = 'Expense' THEN amount ELSE 0 END), 0) AS month_expenses
            FROM transactions 
            WHERE user_id = ? 
              AND MONTH(transaction_date) = ? 
              AND YEAR(transaction_date) = ?`,
            [userId, currentMonth, currentYear]
        );

        const monthIncome = Number(monthTotals[0].month_income);
        const monthExpense = Number(monthTotals[0].month_expenses);

        // 3. Current Month Budget
        const [budgetRows] = await pool.query(
            `SELECT amount FROM budgets WHERE user_id = ? AND month = ? AND year = ?`,
            [userId, currentMonth, currentYear]
        );

        let budgetData = {
            hasBudget: false,
            budget_amount: 0,
            spent: monthExpense,
            remaining: 0,
            percentage: 0,
            status: 'none'
        };

        if (budgetRows.length > 0) {
            const budgetAmt = Number(budgetRows[0].amount);
            const remaining = budgetAmt - monthExpense;
            const percentage = budgetAmt > 0 ? (monthExpense / budgetAmt) * 100 : 0;
            let status = 'safe';
            if (percentage >= 100) status = 'exceeded';
            else if (percentage >= 80) status = 'warning';

            budgetData = {
                hasBudget: true,
                budget_amount: budgetAmt,
                spent: monthExpense,
                remaining,
                percentage: Number(percentage.toFixed(1)),
                status
            };
        }

        // 4. Recent Transactions (latest 7)
        const [recentTransactions] = await pool.query(
            `SELECT 
                t.transaction_id,
                t.amount,
                t.transaction_type,
                t.description,
                DATE_FORMAT(t.transaction_date, '%Y-%m-%d') AS transaction_date,
                COALESCE(c.category_name, 'Uncategorized') AS category_name
            FROM transactions t
            LEFT JOIN categories c ON t.category_id = c.category_id
            WHERE t.user_id = ?
            ORDER BY t.transaction_date DESC, t.transaction_id DESC
            LIMIT 7`,
            [userId]
        );

        // 5. Monthly Trend (Past 6 months)
        const [trendRows] = await pool.query(
            `SELECT 
                YEAR(transaction_date) AS yr,
                MONTH(transaction_date) AS mn,
                COALESCE(SUM(CASE WHEN transaction_type = 'Income' THEN amount ELSE 0 END), 0) AS income,
                COALESCE(SUM(CASE WHEN transaction_type = 'Expense' THEN amount ELSE 0 END), 0) AS expense
            FROM transactions
            WHERE user_id = ? 
              AND transaction_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
            GROUP BY YEAR(transaction_date), MONTH(transaction_date)
            ORDER BY yr ASC, mn ASC`,
            [userId]
        );

        const monthlyTrend = trendRows.map(row => ({
            label: `${MONTH_NAMES[row.mn - 1]} ${row.yr}`,
            income: Number(row.income),
            expense: Number(row.expense),
            savings: Number(row.income) - Number(row.expense)
        }));

        // 6. Category Breakdown for current month (Expense)
        const [categoryBreakdown] = await pool.query(
            `SELECT 
                COALESCE(c.category_name, 'Uncategorized') AS category_name,
                SUM(t.amount) AS total_amount
            FROM transactions t
            LEFT JOIN categories c ON t.category_id = c.category_id
            WHERE t.user_id = ? 
              AND t.transaction_type = 'Expense'
              AND MONTH(t.transaction_date) = ? 
              AND YEAR(t.transaction_date) = ?
            GROUP BY c.category_name
            ORDER BY total_amount DESC`,
            [userId, currentMonth, currentYear]
        );

        return res.json({
            success: true,
            summary: {
                totalIncome,
                totalExpenses,
                currentBalance,
                monthIncome,
                monthExpense,
                totalTransactions: overallTotals[0].total_transactions,
                currentMonth,
                currentYear
            },
            budget: budgetData,
            recentTransactions,
            charts: {
                monthlyTrend,
                categoryBreakdown: categoryBreakdown.map(item => ({
                    category_name: item.category_name,
                    total_amount: Number(item.total_amount)
                }))
            }
        });
    } catch (error) {
        console.error('Dashboard Data Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve dashboard data.'
        });
    }
}

/**
 * Get monthly spending and income report
 * GET /api/reports/monthly?year=2026
 */
async function getMonthlyReport(req, res) {
    try {
        const userId = req.user.id;
        const year = parseInt(req.query.year, 10) || new Date().getFullYear();

        const [rows] = await pool.query(
            `SELECT 
                MONTH(transaction_date) AS month_num,
                COALESCE(SUM(CASE WHEN transaction_type = 'Income' THEN amount ELSE 0 END), 0) AS total_income,
                COALESCE(SUM(CASE WHEN transaction_type = 'Expense' THEN amount ELSE 0 END), 0) AS total_expense,
                COUNT(*) AS count_transactions
            FROM transactions
            WHERE user_id = ? AND YEAR(transaction_date) = ?
            GROUP BY MONTH(transaction_date)
            ORDER BY month_num ASC`,
            [userId, year]
        );

        // Map all 12 months ensuring empty months are represented
        const monthlyReport = [];
        for (let m = 1; m <= 12; m++) {
            const match = rows.find(r => r.month_num === m);
            const inc = match ? Number(match.total_income) : 0;
            const exp = match ? Number(match.total_expense) : 0;
            const net = inc - exp;
            const count = match ? match.count_transactions : 0;

            monthlyReport.push({
                month: m,
                month_name: MONTH_NAMES[m - 1],
                year,
                total_income: inc,
                total_expense: exp,
                net_savings: net,
                savings_rate: inc > 0 ? Number(((net / inc) * 100).toFixed(1)) : 0,
                transaction_count: count
            });
        }

        return res.json({
            success: true,
            year,
            reports: monthlyReport
        });
    } catch (error) {
        console.error('Monthly Report Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to generate monthly report.'
        });
    }
}

/**
 * Get category-wise spending report
 * GET /api/reports/category-wise?startDate=...&endDate=...&type=Expense
 */
async function getCategoryWiseReport(req, res) {
    try {
        const userId = req.user.id;
        const { startDate, endDate, month, year, type = 'Expense' } = req.query;

        let query = `
            SELECT 
                COALESCE(c.category_name, 'Uncategorized') AS category_name,
                c.category_type,
                COUNT(t.transaction_id) AS transaction_count,
                SUM(t.amount) AS total_amount
            FROM transactions t
            LEFT JOIN categories c ON t.category_id = c.category_id
            WHERE t.user_id = ? AND t.transaction_type = ?
        `;
        const params = [userId, type];

        if (month && year) {
            query += ' AND MONTH(t.transaction_date) = ? AND YEAR(t.transaction_date) = ?';
            params.push(parseInt(month, 10), parseInt(year, 10));
        } else if (year && !month) {
            query += ' AND YEAR(t.transaction_date) = ?';
            params.push(parseInt(year, 10));
        }

        if (startDate) {
            query += ' AND t.transaction_date >= ?';
            params.push(startDate);
        }

        if (endDate) {
            query += ' AND t.transaction_date <= ?';
            params.push(endDate);
        }

        query += ' GROUP BY c.category_name, c.category_type ORDER BY total_amount DESC';

        const [rows] = await pool.query(query, params);

        const totalOverall = rows.reduce((acc, curr) => acc + Number(curr.total_amount), 0);

        const formatted = rows.map(item => {
            const amount = Number(item.total_amount);
            const percentage = totalOverall > 0 ? ((amount / totalOverall) * 100) : 0;
            return {
                category_name: item.category_name,
                category_type: item.category_type || type,
                transaction_count: item.transaction_count,
                total_amount: amount,
                percentage: Number(percentage.toFixed(1))
            };
        });

        return res.json({
            success: true,
            type,
            totalOverall,
            categories: formatted
        });
    } catch (error) {
        console.error('Category Report Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to generate category report.'
        });
    }
}

/**
 * Filtered summary report (Daily, Weekly, Monthly, Yearly)
 * GET /api/reports/summary?period=month
 */
async function getSummaryReport(req, res) {
    try {
        const userId = req.user.id;
        const { period = 'month', startDate, endDate } = req.query;

        let dateCondition = '';
        const params = [userId];

        if (startDate && endDate) {
            dateCondition = 'AND transaction_date BETWEEN ? AND ?';
            params.push(startDate, endDate);
        } else if (period === 'today') {
            dateCondition = 'AND transaction_date = CURDATE()';
        } else if (period === 'week') {
            dateCondition = 'AND transaction_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)';
        } else if (period === 'month') {
            dateCondition = 'AND MONTH(transaction_date) = MONTH(CURDATE()) AND YEAR(transaction_date) = YEAR(CURDATE())';
        } else if (period === 'year') {
            dateCondition = 'AND YEAR(transaction_date) = YEAR(CURDATE())';
        }

        // Totals
        const [totals] = await pool.query(
            `SELECT 
                COALESCE(SUM(CASE WHEN transaction_type = 'Income' THEN amount ELSE 0 END), 0) AS total_income,
                COALESCE(SUM(CASE WHEN transaction_type = 'Expense' THEN amount ELSE 0 END), 0) AS total_expense,
                COUNT(*) AS total_count,
                MAX(CASE WHEN transaction_type = 'Expense' THEN amount ELSE 0 END) AS max_expense
            FROM transactions
            WHERE user_id = ? ${dateCondition}`,
            params
        );

        const totalIncome = Number(totals[0].total_income);
        const totalExpense = Number(totals[0].total_expense);
        const netSavings = totalIncome - totalExpense;
        const savingsRate = totalIncome > 0 ? Number(((netSavings / totalIncome) * 100).toFixed(1)) : 0;

        return res.json({
            success: true,
            period,
            summary: {
                totalIncome,
                totalExpense,
                netSavings,
                savingsRate,
                totalTransactions: totals[0].total_count,
                maxExpense: Number(totals[0].max_expense)
            }
        });
    } catch (error) {
        console.error('Summary Report Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to generate summary report.'
        });
    }
}

module.exports = {
    getDashboardData,
    getMonthlyReport,
    getCategoryWiseReport,
    getSummaryReport
};

