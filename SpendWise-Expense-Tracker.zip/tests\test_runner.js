/**
 * Comprehensive API Test Runner for SpendWise
 */

const http = require('http');

const PORT = 3000;
let cookie = '';

function request(method, path, body = null) {
    return new Promise((resolve, reject) => {
        const headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };
        if (cookie) headers['Cookie'] = cookie;

        const req = http.request({
            hostname: 'localhost',
            port: PORT,
            path,
            method,
            headers
        }, (res) => {
            if (res.headers['set-cookie']) {
                cookie = res.headers['set-cookie'].map(c => c.split(';')[0]).join('; ');
            }

            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    const parsed = JSON.parse(data);
                    resolve({ status: res.statusCode, data: parsed });
                } catch (e) {
                    resolve({ status: res.statusCode, raw: data });
                }
            });
        });

        req.on('error', reject);
        if (body) req.write(JSON.stringify(body));
        req.end();
    });
}

async function runTests() {
    console.log('🧪 Starting End-to-End API Test Suite...');
    let passed = 0;
    let failed = 0;

    function assert(condition, name) {
        if (condition) {
            console.log(`  ✅ [PASS] ${name}`);
            passed++;
        } else {
            console.error(`  ❌ [FAIL] ${name}`);
            failed++;
        }
    }

    try {
        // 1. Test Login with Demo User
        console.log('\n--- 1. Authentication Tests ---');
        const loginRes = await request('POST', '/api/auth/login', {
            email: 'demo@expensetracker.com',
            password: 'password123'
        });
        assert(loginRes.status === 200 && loginRes.data.success === true, 'Login with Demo credentials');

        // 2. Test Get Current Session (/api/auth/me)
        const meRes = await request('GET', '/api/auth/me');
        assert(meRes.status === 200 && meRes.data.user.email === 'demo@expensetracker.com', 'Get current session (/api/auth/me)');

        // 3. Test Dashboard API
        console.log('\n--- 2. Dashboard & Summary Tests ---');
        const dashRes = await request('GET', '/api/dashboard');
        assert(dashRes.status === 200 && dashRes.data.success === true, 'Retrieve Dashboard analytics');
        assert(typeof dashRes.data.summary.totalIncome === 'number', 'Summary contains totalIncome number');
        assert(typeof dashRes.data.summary.currentBalance === 'number', 'Summary contains currentBalance number');

        // 4. Test Categories API
        console.log('\n--- 3. Category Management Tests ---');
        const catRes = await request('GET', '/api/categories');
        assert(catRes.status === 200 && Array.isArray(catRes.data.categories), 'Retrieve all user categories');

        const newCatRes = await request('POST', '/api/categories', {
            category_name: 'Test Category ' + Date.now(),
            category_type: 'Expense'
        });
        assert(newCatRes.status === 201 && newCatRes.data.category.category_id > 0, 'Create new category');
        const createdCatId = newCatRes.data.category.category_id;

        // 5. Test Transactions API
        console.log('\n--- 4. Transaction Management Tests ---');
        const createTransRes = await request('POST', '/api/transactions', {
            amount: 75.50,
            transaction_type: 'Expense',
            category_id: createdCatId,
            transaction_date: '2026-11-06',
            description: 'Automated test expense for coffee & books'
        });
        assert(createTransRes.status === 201 && createTransRes.data.transaction.transaction_id > 0, 'Create new expense transaction');
        const createdTransId = createTransRes.data.transaction.transaction_id;

        const transListRes = await request('GET', '/api/transactions?type=Expense');
        assert(transListRes.status === 200 && transListRes.data.transactions.length > 0, 'Filter transactions by type=Expense');

        const updateTransRes = await request('PUT', `/api/transactions/${createdTransId}`, {
            amount: 80.00,
            transaction_type: 'Expense',
            category_id: createdCatId,
            transaction_date: '2026-11-06',
            description: 'Updated test expense'
        });
        assert(updateTransRes.status === 200 && updateTransRes.data.success === true, 'Update transaction');

        // 6. Test Budget API
        console.log('\n--- 5. Budget Management Tests ---');
        const setBudgetRes = await request('POST', '/api/budgets', {
            amount: 3500.00,
            month: 11,
            year: 2026
        });
        assert(setBudgetRes.status === 201 && setBudgetRes.data.success === true, 'Set monthly budget for 11/2026');

        const currentBudgetRes = await request('GET', '/api/budgets/current?month=11&year=2026');
        assert(currentBudgetRes.status === 200 && currentBudgetRes.data.budget.budget_amount === 3500, 'Get current budget calculations');

        // 7. Test Reports API
        console.log('\n--- 6. Reports & Analytics Tests ---');
        const monthlyReportRes = await request('GET', '/api/reports/monthly?year=2026');
        assert(monthlyReportRes.status === 200 && monthlyReportRes.data.reports.length === 12, '12-month report generation');

        const catReportRes = await request('GET', '/api/reports/category-wise?type=Expense');
        assert(catReportRes.status === 200 && Array.isArray(catReportRes.data.categories), 'Category-wise spending report');

        // 8. Clean up created test transaction and category
        console.log('\n--- 7. Cleanup & Teardown ---');
        const delTransRes = await request('DELETE', `/api/transactions/${createdTransId}`);
        assert(delTransRes.status === 200, 'Delete test transaction');

        const delCatRes = await request('DELETE', `/api/categories/${createdCatId}`);
        assert(delCatRes.status === 200, 'Delete test category');

        // 9. Logout
        const logoutRes = await request('POST', '/api/auth/logout');
        assert(logoutRes.status === 200, 'Logout user');

        console.log(`\n========================================`);
        console.log(`Test Results: ${passed} Passed, ${failed} Failed`);
        console.log(`========================================`);

        process.exit(failed > 0 ? 1 : 0);
    } catch (e) {
        console.error('Test Runner Exception:', e);
        process.exit(1);
    }
}

runTests();

