const { pool } = require('../config/db');

/**
 * Get all categories for current user
 * GET /api/categories
 * Optional query: ?type=Income or ?type=Expense
 */
async function getCategories(req, res) {
    try {
        const userId = req.user.id;
        const { type } = req.query;

        let query = `
            SELECT 
                c.category_id,
                c.category_name,
                c.category_type,
                c.created_at,
                COUNT(t.transaction_id) AS transaction_count,
                COALESCE(SUM(t.amount), 0) AS total_spent
            FROM categories c
            LEFT JOIN transactions t ON c.category_id = t.category_id AND t.user_id = ?
            WHERE c.user_id = ?
        `;
        const params = [userId, userId];

        if (type && ['Income', 'Expense'].includes(type)) {
            query += ' AND c.category_type = ?';
            params.push(type);
        }

        query += ' GROUP BY c.category_id, c.category_name, c.category_type, c.created_at ORDER BY c.category_type ASC, c.category_name ASC';

        const [categories] = await pool.query(query, params);

        return res.json({
            success: true,
            count: categories.length,
            categories
        });
    } catch (error) {
        console.error('Get Categories Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve categories.'
        });
    }
}

/**
 * Create a new category
 * POST /api/categories
 */
async function createCategory(req, res) {
    try {
        const userId = req.user.id;
        const { category_name, category_type } = req.body;

        if (!category_name || !category_type) {
            return res.status(400).json({
                success: false,
                message: 'Category name and category type (Income/Expense) are required.'
            });
        }

        const trimmedName = category_name.trim();
        const validTypes = ['Income', 'Expense'];

        if (!validTypes.includes(category_type)) {
            return res.status(400).json({
                success: false,
                message: 'Category type must be either "Income" or "Expense".'
            });
        }

        if (trimmedName.length < 2 || trimmedName.length > 100) {
            return res.status(400).json({
                success: false,
                message: 'Category name must be between 2 and 100 characters.'
            });
        }

        // Check for duplicate category name for this user
        const [existing] = await pool.query(
            'SELECT category_id FROM categories WHERE user_id = ? AND LOWER(category_name) = LOWER(?) AND category_type = ?',
            [userId, trimmedName, category_type]
        );

        if (existing.length > 0) {
            return res.status(409).json({
                success: false,
                message: `Category "${trimmedName}" already exists for ${category_type}.`
            });
        }

        const [result] = await pool.query(
            'INSERT INTO categories (user_id, category_name, category_type) VALUES (?, ?, ?)',
            [userId, trimmedName, category_type]
        );

        return res.status(201).json({
            success: true,
            message: 'Category created successfully.',
            category: {
                category_id: result.insertId,
                user_id: userId,
                category_name: trimmedName,
                category_type
            }
        });
    } catch (error) {
        console.error('Create Category Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to create category.'
        });
    }
}

/**
 * Update an existing category
 * PUT /api/categories/:id
 */
async function updateCategory(req, res) {
    try {
        const userId = req.user.id;
        const categoryId = parseInt(req.params.id, 10);
        const { category_name, category_type } = req.body;

        if (!categoryId) {
            return res.status(400).json({ success: false, message: 'Invalid category ID.' });
        }

        if (!category_name || !category_type) {
            return res.status(400).json({
                success: false,
                message: 'Category name and category type are required.'
            });
        }

        const trimmedName = category_name.trim();
        if (!['Income', 'Expense'].includes(category_type)) {
            return res.status(400).json({ success: false, message: 'Invalid category type.' });
        }

        // Verify category belongs to user
        const [existing] = await pool.query(
            'SELECT category_id FROM categories WHERE category_id = ? AND user_id = ?',
            [categoryId, userId]
        );

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Category not found or unauthorized.'
            });
        }

        // Check for duplicate with different ID
        const [duplicate] = await pool.query(
            'SELECT category_id FROM categories WHERE user_id = ? AND LOWER(category_name) = LOWER(?) AND category_type = ? AND category_id != ?',
            [userId, trimmedName, category_type, categoryId]
        );

        if (duplicate.length > 0) {
            return res.status(409).json({
                success: false,
                message: `Another category named "${trimmedName}" already exists for ${category_type}.`
            });
        }

        await pool.query(
            'UPDATE categories SET category_name = ?, category_type = ? WHERE category_id = ? AND user_id = ?',
            [trimmedName, category_type, categoryId, userId]
        );

        return res.json({
            success: true,
            message: 'Category updated successfully.',
            category: {
                category_id: categoryId,
                category_name: trimmedName,
                category_type
            }
        });
    } catch (error) {
        console.error('Update Category Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to update category.'
        });
    }
}

/**
 * Delete a category
 * DELETE /api/categories/:id
 */
async function deleteCategory(req, res) {
    try {
        const userId = req.user.id;
        const categoryId = parseInt(req.params.id, 10);

        if (!categoryId) {
            return res.status(400).json({ success: false, message: 'Invalid category ID.' });
        }

        const [existing] = await pool.query(
            'SELECT category_id, category_name FROM categories WHERE category_id = ? AND user_id = ?',
            [categoryId, userId]
        );

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Category not found or unauthorized.'
            });
        }

        await pool.query(
            'DELETE FROM categories WHERE category_id = ? AND user_id = ?',
            [categoryId, userId]
        );

        return res.json({
            success: true,
            message: `Category "${existing[0].category_name}" deleted successfully.`
        });
    } catch (error) {
        console.error('Delete Category Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to delete category.'
        });
    }
}

module.exports = {
    getCategories,
    createCategory,
    updateCategory,
    deleteCategory
};

