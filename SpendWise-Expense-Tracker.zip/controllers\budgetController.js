const { pool } = require('../config/db');

/**
 * Get all budgets for current user with spending calculations
 * GET /api/budgets
 */
async function getBudgets(req, res) {
    try {
        const userId = req.user.id;

        const [budgets] = await pool.query(
            `SELECT 
                b.budget_id,
                b.user_id,
                b.amount AS budget_amount,
                b.month,
                b.year,
                b.created_at,
                COALESCE((
                    SELECT SUM(t.amount) 
                    FROM transactions t 
                    WHERE t.user_id = b.user_id 
                      AND t.transaction_type = 'Expense'
                      AND MONTH(t.transaction_date) = b.month 
                      AND YEAR(t.transaction_date) = b.year
                ), 0) AS total_spent
            FROM budgets b
            WHERE b.user_id = ?
            ORDER BY b.year DESC, b.month DESC`,
            [userId]
        );

        // Add calculated fields
        const formattedBudgets = budgets.map(b => {
            const budgetAmt = Number(b.budget_amount);
            const spent = Number(b.total_spent);
            const remaining = budgetAmt - spent;
            const percentage = budgetAmt > 0 ? ((spent / budgetAmt) * 100) : 0;

            let status = 'safe';
            if (percentage >= 100) {
                status = 'exceeded';
            } else if (percentage >= 80) {
                status = 'warning';
            }

            return {
                ...b,
                budget_amount: budgetAmt,
                total_spent: spent,
                remaining,
                percentage: Number(percentage.toFixed(1)),
                status
            };
        });

        return res.json({
            success: true,
            budgets: formattedBudgets
        });
    } catch (error) {
        console.error('Get Budgets Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve budgets.'
        });
    }
}

/**
 * Get budget for a specific month & year (or current month)
 * GET /api/budgets/current?month=11&year=2026
 */
async function getCurrentBudget(req, res) {
    try {
        const userId = req.user.id;
        const now = new Date();
        const month = parseInt(req.query.month, 10) || (now.getMonth() + 1);
        const year = parseInt(req.query.year, 10) || now.getFullYear();

        const [rows] = await pool.query(
            `SELECT 
                b.budget_id,
                b.amount AS budget_amount,
                b.month,
                b.year,
                COALESCE((
                    SELECT SUM(t.amount) 
                    FROM transactions t 
                    WHERE t.user_id = b.user_id 
                      AND t.transaction_type = 'Expense'
                      AND MONTH(t.transaction_date) = b.month 
                      AND YEAR(t.transaction_date) = b.year
                ), 0) AS total_spent
            FROM budgets b
            WHERE b.user_id = ? AND b.month = ? AND b.year = ?`,
            [userId, month, year]
        );

        if (rows.length === 0) {
            // Also calculate total spent this month even if no budget is explicitly set yet
            const [spentRows] = await pool.query(
                `SELECT COALESCE(SUM(amount), 0) AS total_spent
                 FROM transactions 
                 WHERE user_id = ? 
                   AND transaction_type = 'Expense'
                   AND MONTH(transaction_date) = ? 
                   AND YEAR(transaction_date) = ?`,
                [userId, month, year]
            );

            return res.json({
                success: true,
                hasBudget: false,
                budget: {
                    month,
                    year,
                    budget_amount: 0,
                    total_spent: Number(spentRows[0].total_spent),
                    remaining: 0,
                    percentage: 0,
                    status: 'none'
                }
            });
        }

        const b = rows[0];
        const budgetAmt = Number(b.budget_amount);
        const spent = Number(b.total_spent);
        const remaining = budgetAmt - spent;
        const percentage = budgetAmt > 0 ? ((spent / budgetAmt) * 100) : 0;

        let status = 'safe';
        if (percentage >= 100) {
            status = 'exceeded';
        } else if (percentage >= 80) {
            status = 'warning';
        }

        return res.json({
            success: true,
            hasBudget: true,
            budget: {
                budget_id: b.budget_id,
                month: b.month,
                year: b.year,
                budget_amount: budgetAmt,
                total_spent: spent,
                remaining,
                percentage: Number(percentage.toFixed(1)),
                status
            }
        });
    } catch (error) {
        console.error('Get Current Budget Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve current budget.'
        });
    }
}

/**
 * Set or Update Monthly Budget (Upsert)
 * POST /api/budgets
 */
async function setBudget(req, res) {
    try {
        const userId = req.user.id;
        const { amount, month, year } = req.body;

        const parsedAmount = parseFloat(amount);
        const parsedMonth = parseInt(month, 10);
        const parsedYear = parseInt(year, 10);

        if (isNaN(parsedAmount) || parsedAmount <= 0) {
            return res.status(400).json({
                success: false,
                message: 'Budget amount must be a positive number.'
            });
        }

        if (isNaN(parsedMonth) || parsedMonth < 1 || parsedMonth > 12) {
            return res.status(400).json({
                success: false,
                message: 'Month must be between 1 and 12.'
            });
        }

        if (isNaN(parsedYear) || parsedYear < 2000 || parsedYear > 2100) {
            return res.status(400).json({
                success: false,
                message: 'Please provide a valid 4-digit year.'
            });
        }

        // Upsert budget into MySQL
        await pool.query(
            `INSERT INTO budgets (user_id, amount, month, year)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE amount = VALUES(amount)`,
            [userId, parsedAmount.toFixed(2), parsedMonth, parsedYear]
        );

        return res.status(201).json({
            success: true,
            message: `Budget of $${parsedAmount.toFixed(2)} set for ${parsedMonth}/${parsedYear}.`
        });
    } catch (error) {
        console.error('Set Budget Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to set budget.'
        });
    }
}

/**
 * Update budget by ID
 * PUT /api/budgets/:id
 */
async function updateBudget(req, res) {
    try {
        const userId = req.user.id;
        const budgetId = parseInt(req.params.id, 10);
        const { amount } = req.body;

        const parsedAmount = parseFloat(amount);
        if (isNaN(parsedAmount) || parsedAmount <= 0) {
            return res.status(400).json({
                success: false,
                message: 'Budget amount must be a positive number.'
            });
        }

        const [existing] = await pool.query(
            'SELECT budget_id FROM budgets WHERE budget_id = ? AND user_id = ?',
            [budgetId, userId]
        );

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Budget record not found or unauthorized.'
            });
        }

        await pool.query(
            'UPDATE budgets SET amount = ? WHERE budget_id = ? AND user_id = ?',
            [parsedAmount.toFixed(2), budgetId, userId]
        );

        return res.json({
            success: true,
            message: 'Budget updated successfully.'
        });
    } catch (error) {
        console.error('Update Budget Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to update budget.'
        });
    }
}

/**
 * Delete budget by ID
 * DELETE /api/budgets/:id
 */
async function deleteBudget(req, res) {
    try {
        const userId = req.user.id;
        const budgetId = parseInt(req.params.id, 10);

        const [existing] = await pool.query(
            'SELECT budget_id FROM budgets WHERE budget_id = ? AND user_id = ?',
            [budgetId, userId]
        );

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Budget not found or unauthorized.'
            });
        }

        await pool.query(
            'DELETE FROM budgets WHERE budget_id = ? AND user_id = ?',
            [budgetId, userId]
        );

        return res.json({
            success: true,
            message: 'Budget deleted successfully.'
        });
    } catch (error) {
        console.error('Delete Budget Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to delete budget.'
        });
    }
}

module.exports = {
    getBudgets,
    getCurrentBudget,
    setBudget,
    updateBudget,
    deleteBudget
};

