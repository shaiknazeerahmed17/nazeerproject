# SpendWise — Personal Expense Tracker Management System

![Project License](https://img.shields.io/badge/license-ISC-blue.svg)
![Node Version](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen.svg)
![Express Version](https://img.shields.io/badge/express-v5.2.1-lightgrey.svg)
![MySQL Version](https://img.shields.io/badge/mysql-v8.0-orange.svg)
![Database](https://img.shields.io/badge/database-expense__tracker__db-blue)

A complete, full-stack, responsive web application for managing personal income, expenditures, custom categories, monthly budgets, and interactive visual financial reports.

---

## 1. Project Overview & Identity

- **Project Title:** Personal Expense Tracker Management System
- **Platform Name:** SpendWise
- **Tagline:** *"Take Full Control of Your Money with Smart Financial Tracking"*
- **Target Audience:** Individuals, students, freelancers, and professionals looking to optimize their personal cashflow, stick to monthly budgets, and analyze spending patterns.

---

## 2. Objectives

1. **Financial Discipline:** Enable users to log every income stream and expense transaction with granular date and category details.
2. **Budget Adherence:** Establish monthly spending thresholds and provide automated real-time visual warnings (Safe, Approaching 80%, Exceeded 100%) to prevent overspending.
3. **Data-Driven Insights:** Provide interactive Chart.js visualizations (bar charts, doughnut charts, multi-month trends) and downloadable CSV transaction ledgers.
4. **Security & Privacy:** Ensure strict user data isolation, password hashing with bcrypt, session authentication, and SQL injection prevention via prepared statements.

---

## 3. Technology Stack

### Frontend:
- **HTML5:** Semantic, accessible application structure.
- **CSS3:** Custom SaaS design system, CSS variables, flexbox, CSS grid, and responsive layouts.
- **JavaScript (ES6+):** Asynchronous API integration, dynamic DOM manipulation, toast notifications, and modal managers.
- **Chart.js:** Interactive bar charts, multi-month cashflow comparisons, and category doughnut charts.
- **FontAwesome 6:** Clean iconography for navigation, metrics, and actions.
- **Google Fonts:** Plus Jakarta Sans & Inter typography with tabular numeric alignment.

### Backend:
- **Node.js:** Event-driven server runtime environment.
- **Express.js:** RESTful API architecture, routing middleware, and static asset serving.
- **express-session:** Server-side user session management with secure cookies.
- **bcryptjs:** Industry-standard password hashing (salt rounds: 10).
- **dotenv:** Centralized environment variable configuration.
- **cors:** Cross-Origin Resource Sharing handling.

### Database:
- **MySQL 8.0:** Relational database management system.
- **mysql2/promise:** High-performance connection pool supporting async/await and SQL parameterized queries.

---

## 4. Main Functional Modules

### 👤 Module 1: User Authentication & Security
- Secure registration with client-side and server-side validation.
- Duplicate email prevention.
- Password hashing with `bcryptjs`.
- Session-based authentication with `express-session`.
- Automatic seeding of 11 starter categories upon new user registration.
- Route protection middleware (`requireAuth`) for both HTML pages and REST endpoints.

### 📊 Module 2: Interactive Financial Dashboard
- **Key Performance Indicators (KPIs):** Total Income, Total Expenses, Current Balance, and Monthly Budget.
- **Real-Time Budget Meter:** Dynamic progress bar showing consumption percentage and alert statuses (`Safe`, `Near Limit 80%+`, `Budget Exceeded`).
- **Income vs Expense Chart:** Multi-month bar chart powered by Chart.js.
- **Category Doughnut Chart:** Breakdown of current month's expenses.
- **Recent Transactions Ledger:** Quick overview of latest transactions with color-coded badges and tabular numeric currency formatting.
- **Quick Add Transaction Modal:** Instant transaction recording directly from the dashboard.

### 💳 Module 3: Income & Expense Management
- Full CRUD operations: Create, Read, Update, Delete transactions.
- Flexible filtering by transaction type (`All`, `Income`, `Expense`).
- Filter by category with dynamic dropdown population.
- Filter by date range (Start Date to End Date).
- Real-time search across transaction descriptions and category names.
- Instant filtered totals strip (Total Records, Filtered Income, Filtered Expense, Net Difference).
- Export complete transaction history to CSV format.

### 🏷️ Module 4: Custom Category Management
- Create custom categories under either `Income` or `Expense`.
- Filter categories by type tabs (`All`, `Expense`, `Income`).
- Track volume statistics: total transactions count and total volume spent/earned per category.
- Update category names and types.
- Delete categories safely with `ON DELETE SET NULL` foreign key handling to protect historical transactions.

### 🎯 Module 5: Monthly Budget Management
- Allocate target spending budgets for any given month and year.
- Automatically calculates:
  - Allocated Budget Amount
  - Total Actual Spent
  - Remaining Balance
  - Percentage Used
- Visual warning banners:
  - **On Track (<80%):** Positive reinforcement.
  - **Warning (80%-99%):** Approaching budget limit.
  - **Exceeded (>=100%):** Prominent alert banner highlighting overspent amount.
- Historical Monthly Budgets table with progress bars, status badges, and deletion controls.

### 📈 Module 6: Spending Reports & Analytics
- Multi-period analysis tabs:
  - **Daily (Today)**
  - **This Week**
  - **This Month**
  - **This Year**
  - **Custom Date Interval**
- Comprehensive metrics: Total Income, Total Expenses, Net Savings, and Savings Rate (%).
- Category Spending Distribution doughnut chart and volume progress table.
- Annual Month-by-Month Income vs Expense Bar Chart.
- Detailed 12-month summary ledger.
- One-click **Print Report** button for physical or PDF documentation.

### ⚙️ Module 7: User Profile & Account Settings
- Account summary: Member since date, total transactions logged, active categories, and budgets set.
- Update user display name.
- Change password with existing password verification and hashing.

---

## 5. Database Design (`expense_tracker_db`)

The relational database is normalized and enforces referential integrity through foreign keys with cascade and nullification rules.

### Table 1: `users`
| Field Name | Data Type | Constraint | Description |
|---|---|---|---|
| `id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique user identifier |
| `name` | VARCHAR(50) | NOT NULL | User's full name |
| `email` | VARCHAR(100) | UNIQUE, NOT NULL | Account login email |
| `password` | VARCHAR(225) | NOT NULL | Bcrypt hashed password |
| `created_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Account creation timestamp |

### Table 2: `categories`
| Field Name | Data Type | Constraint | Description |
|---|---|---|---|
| `category_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique category identifier |
| `user_id` | INT | FOREIGN KEY (`users.id`) ON DELETE CASCADE | Associated user |
| `category_name` | VARCHAR(100) | NOT NULL | Name (e.g. Food, Salary) |
| `category_type` | VARCHAR(20) | NOT NULL | Either 'Income' or 'Expense' |
| `created_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Creation timestamp |

### Table 3: `transactions`
| Field Name | Data Type | Constraint | Description |
|---|---|---|---|
| `transaction_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique transaction identifier |
| `user_id` | INT | FOREIGN KEY (`users.id`) ON DELETE CASCADE | Associated user |
| `category_id` | INT | FOREIGN KEY (`categories.category_id`) ON DELETE SET NULL | Associated category |
| `amount` | DECIMAL(10,2) | NOT NULL | Transaction value |
| `transaction_type` | VARCHAR(20) | NOT NULL | Either 'Income' or 'Expense' |
| `description` | VARCHAR(225) | NULL | Transaction notes/memo |
| `transaction_date` | DATE | NOT NULL | Transaction date |
| `created_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Entry creation timestamp |

### Table 4: `budgets`
| Field Name | Data Type | Constraint | Description |
|---|---|---|---|
| `budget_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique budget identifier |
| `user_id` | INT | FOREIGN KEY (`users.id`) ON DELETE CASCADE | Associated user |
| `amount` | DECIMAL(10,2) | NOT NULL | Monthly budget limit |
| `month` | INT | NOT NULL (1 to 12) | Target month |
| `year` | INT | NOT NULL | Target year |
| `created_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Timestamp |
| *Constraint* | UNIQUE KEY | `uq_user_month_year` (`user_id`, `month`, `year`) | One budget per month per user |

---

## 6. Project Directory Structure

```
nazeer mini project/
├── config/
│   └── db.js                    # MySQL connection pooling & auto-initialization
├── controllers/
│   ├── authController.js        # Register, login, logout, getMe
│   ├── categoryController.js    # Category CRUD & transaction aggregations
│   ├── transactionController.js # Transaction CRUD, search, filter, CSV export
│   ├── budgetController.js      # Budget calculation, progress & alerts
│   ├── reportController.js      # Summary, monthly, category analytics
│   └── userController.js        # Profile info, name update, password change
├── routes/
│   ├── authRoutes.js            # /api/auth/*
│   ├── categoryRoutes.js        # /api/categories/*
│   ├── transactionRoutes.js     # /api/transactions/*
│   ├── budgetRoutes.js          # /api/budgets/*
│   ├── reportRoutes.js          # /api/reports/*
│   └── userRoutes.js            # /api/user/*
├── middleware/
│   └── authMiddleware.js        # Session check & API authorization guard
├── database/
│   ├── schema.sql               # MySQL DDL table creation script
│   ├── sample_data.sql          # Demo user, categories, transactions, budgets
│   └── initDb.js                # One-click automated database initialization CLI
├── public/
│   ├── index.html               # Public landing & feature showcase page
│   ├── login.html               # Secure login interface with demo auto-fill
│   ├── register.html            # Registration interface
│   ├── dashboard.html           # Main financial dashboard
│   ├── transactions.html        # Transactions manager with search & CSV
│   ├── categories.html          # Custom categories manager
│   ├── budget.html              # Monthly budget manager with alert meters
│   ├── reports.html             # Spending reports with Chart.js analytics
│   ├── profile.html             # Account profile & password updater
│   ├── css/
│   │   ├── style.css            # Global design tokens, buttons, badges, modals
│   │   └── dashboard.css        # Sidebar layout, cards, tables, progress meters
│   └── js/
│       ├── api.js               # Centralized API fetch wrapper & toasts
│       ├── auth.js              # Login & registration forms
│       ├── dashboard.js         # Dashboard metrics & Chart.js instances
│       ├── transactions.js      # Transaction CRUD, filters & CSV export
│       ├── categories.js        # Category CRUD & tab filters
│       ├── budget.js            # Budget calculations & progress bars
│       ├── reports.js           # Reporting periods & annual trend charts
│       └── profile.js           # Profile details & password change
├── tests/
│   └── test_runner.js           # Automated end-to-end API test suite
├── .env                         # Local environment variables (DB credentials)
├── .env.example                 # Template for repository users
├── .gitignore                   # Ignores node_modules, .env, and logs
├── package.json                 # Project dependencies and npm scripts
├── server.js                    # Express application entrypoint
└── README.md                    # Comprehensive documentation
```

---

## 7. Installation & Setup Guide

### Prerequisites
- [Node.js](https://nodejs.org/) (v18.0.0 or higher)
- [MySQL Server](https://dev.mysql.com/downloads/mysql/) (v8.0 or higher) / MySQL Workbench

### Step 1: Clone or Open the Repository
```bash
cd "nazeer mini project"
```

### Step 2: Install Node Dependencies
```bash
npm install
```

### Step 3: Configure Database Credentials
Create a `.env` file in the root directory (or copy from `.env.example`):
```env
PORT=3000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=manzoor
DB_NAME=expense_tracker_db
DB_PORT=3306
SESSION_SECRET=spendwise_secure_session_key_2026
NODE_ENV=development
```
*(Replace `manzoor` with your local MySQL root password if different).*

### Step 4: Initialize the MySQL Database
You can initialize the database tables and populate rich sample data using the automated setup script:
```bash
npm run init-db
```
*Alternatively, you can open MySQL Workbench and execute `database/schema.sql` followed by `database/sample_data.sql`.*

### Step 5: Start the Application
To run in production mode:
```bash
npm start
```

To run with auto-reload during development:
```bash
npm run dev
```

### Step 6: Access the Application
Open your web browser and navigate to:
```
http://localhost:3000
```

---

## 8. Demo Credentials

You can explore all features immediately using the pre-configured demo account:
- **Email:** `demo@expensetracker.com`
- **Password:** `password123`

*(A one-click **"Auto Fill"** button is also available directly on the login page for convenience).*

---

## 9. Running the Automated Test Suite

A comprehensive test suite is included in `tests/test_runner.js`. It validates authentication, session security, category CRUD, transaction handling, budget calculations, and report generation:

Ensure the server is running, then execute:
```bash
npm test
```
**Expected Output:** `Test Results: 17 Passed, 0 Failed`.

---

## 10. REST API Specification

| Method | Endpoint | Description | Protected |
|---|---|---|:---:|
| `POST` | `/api/auth/register` | Register new account and seed default categories | No |
| `POST` | `/api/auth/login` | Authenticate user credentials and start session | No |
| `POST` | `/api/auth/logout` | Terminate session and clear cookie | Yes |
| `GET` | `/api/auth/me` | Fetch currently authenticated user | Yes |
| `GET` | `/api/dashboard` | Retrieve lifetime and monthly KPIs, recent logs, charts | Yes |
| `GET` | `/api/transactions` | Query transactions with filters (`type`, `category`, `search`, `dates`) | Yes |
| `POST` | `/api/transactions` | Record a new income or expense transaction | Yes |
| `PUT` | `/api/transactions/:id` | Update an existing transaction | Yes |
| `DELETE` | `/api/transactions/:id` | Remove a transaction | Yes |
| `GET` | `/api/transactions/export/csv` | Download complete transaction history as CSV | Yes |
| `GET` | `/api/categories` | Retrieve all custom categories with usage counts | Yes |
| `POST` | `/api/categories` | Create a new custom category | Yes |
| `PUT` | `/api/categories/:id` | Update category name and type | Yes |
| `DELETE` | `/api/categories/:id` | Delete category safely | Yes |
| `GET` | `/api/budgets` | Retrieve all monthly budgets with spending calculations | Yes |
| `GET` | `/api/budgets/current` | Retrieve budget & alert status for selected month/year | Yes |
| `POST` | `/api/budgets` | Set or update monthly budget target (Upsert) | Yes |
| `DELETE` | `/api/budgets/:id` | Delete a budget record | Yes |
| `GET` | `/api/reports/monthly` | 12-month annual income vs expense comparison | Yes |
| `GET` | `/api/reports/category-wise` | Category spending breakdown with percentages | Yes |
| `GET` | `/api/reports/summary` | Period summary KPIs (`today`, `week`, `month`, `year`) | Yes |
| `GET` | `/api/user/profile` | Retrieve account info and usage statistics | Yes |
| `PUT` | `/api/user/profile` | Update user display name | Yes |
| `PUT` | `/api/user/password` | Change user account password | Yes |

---

## 11. Security Implementation

- **Bcrypt Password Hashing:** User passwords are encrypted with a cryptographic salt before database storage.
- **Session Isolation:** User IDs are pulled directly from the verified server-side session (`req.session.user.id`). No user can access, query, or modify another user's financial records.
- **SQL Injection Prevention:** Every database query strictly uses SQL parameterized statements (`?` placeholders) with `mysql2`.
- **Cross-Site Scripting (XSS) Protection:** All dynamic frontend DOM nodes are constructed via textContent and sanitization helpers.
- **Negative Balance & Zero Validation:** Numeric transaction values and budgets must be positive decimals greater than zero.

---

## 12. Future Enhancements

- [ ] Multi-currency selection with live exchange rates.
- [ ] Automated recurring transactions (e.g. monthly subscriptions, rent).
- [ ] Receipt image upload & optical character recognition (OCR).
- [ ] Email notifications for budget threshold warnings.
- [ ] Two-factor authentication (2FA).

---

## 13. License

This project is licensed under the **ISC License**. Developed as an engineering-grade full-stack mini project ready for university practical evaluation, GitHub showcase, and portfolio demonstration.

