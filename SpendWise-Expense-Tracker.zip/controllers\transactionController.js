const { pool } = require('../config/db');

/**
 * Get all transactions with flexible search & filtering
 * GET /api/transactions
 */
async function getTransactions(req, res) {
    try {
        const userId = req.user.id;
        const {
            startDate,
            endDate,
            categoryId,
            type,
            search,
            limit = 100,
            offset = 0
        } = req.query;

        let query = `
            SELECT 
                t.transaction_id,
                t.user_id,
                t.category_id,
                t.amount,
                t.transaction_type,
                t.description,
                DATE_FORMAT(t.transaction_date, '%Y-%m-%d') AS transaction_date,
                t.created_at,
                c.category_name,
                c.category_type
            FROM transactions t
            LEFT JOIN categories c ON t.category_id = c.category_id
            WHERE t.user_id = ?
        `;
        const params = [userId];

        if (type && ['Income', 'Expense'].includes(type)) {
            query += ' AND t.transaction_type = ?';
            params.push(type);
        }

        if (categoryId && !isNaN(parseInt(categoryId, 10))) {
            query += ' AND t.category_id = ?';
            params.push(parseInt(categoryId, 10));
        }

        if (startDate) {
            query += ' AND t.transaction_date >= ?';
            params.push(startDate);
        }

        if (endDate) {
            query += ' AND t.transaction_date <= ?';
            params.push(endDate);
        }

        if (search && search.trim() !== '') {
            query += ' AND (t.description LIKE ? OR c.category_name LIKE ?)';
            const term = `%${search.trim()}%`;
            params.push(term, term);
        }

        query += ' ORDER BY t.transaction_date DESC, t.transaction_id DESC';

        // Add limit and offset
        const safeLimit = Math.min(Math.max(parseInt(limit, 10) || 50, 1), 500);
        const safeOffset = Math.max(parseInt(offset, 10) || 0, 0);

        query += ` LIMIT ${safeLimit} OFFSET ${safeOffset}`;

        const [transactions] = await pool.query(query, params);

        // Also calculate totals for the filtered set
        let countQuery = `
            SELECT 
                COUNT(*) AS total_count,
                COALESCE(SUM(CASE WHEN t.transaction_type = 'Income' THEN t.amount ELSE 0 END), 0) AS total_income,
                COALESCE(SUM(CASE WHEN t.transaction_type = 'Expense' THEN t.amount ELSE 0 END), 0) AS total_expense
            FROM transactions t
            LEFT JOIN categories c ON t.category_id = c.category_id
            WHERE t.user_id = ?
        `;
        const countParams = [userId];

        if (type && ['Income', 'Expense'].includes(type)) {
            countQuery += ' AND t.transaction_type = ?';
            countParams.push(type);
        }
        if (categoryId && !isNaN(parseInt(categoryId, 10))) {
            countQuery += ' AND t.category_id = ?';
            countParams.push(parseInt(categoryId, 10));
        }
        if (startDate) {
            countQuery += ' AND t.transaction_date >= ?';
            countParams.push(startDate);
        }
        if (endDate) {
            countQuery += ' AND t.transaction_date <= ?';
            countParams.push(endDate);
        }
        if (search && search.trim() !== '') {
            countQuery += ' AND (t.description LIKE ? OR c.category_name LIKE ?)';
            const term = `%${search.trim()}%`;
            countParams.push(term, term);
        }

        const [summaryRows] = await pool.query(countQuery, countParams);
        const summary = summaryRows[0] || { total_count: 0, total_income: 0, total_expense: 0 };
        const netBalance = Number(summary.total_income) - Number(summary.total_expense);

        return res.json({
            success: true,
            transactions,
            totalCount: summary.total_count,
            summary: {
                totalIncome: Number(summary.total_income),
                totalExpense: Number(summary.total_expense),
                netBalance
            }
        });
    } catch (error) {
        console.error('Get Transactions Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve transactions.'
        });
    }
}

/**
 * Get single transaction by ID
 * GET /api/transactions/:id
 */
async function getTransactionById(req, res) {
    try {
        const userId = req.user.id;
        const transactionId = parseInt(req.params.id, 10);

        const [rows] = await pool.query(
            `SELECT 
                t.transaction_id,
                t.user_id,
                t.category_id,
                t.amount,
                t.transaction_type,
                t.description,
                DATE_FORMAT(t.transaction_date, '%Y-%m-%d') AS transaction_date,
                t.created_at,
                c.category_name
            FROM transactions t
            LEFT JOIN categories c ON t.category_id = c.category_id
            WHERE t.transaction_id = ? AND t.user_id = ?`,
            [transactionId, userId]
        );

        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Transaction not found.'
            });
        }

        return res.json({
            success: true,
            transaction: rows[0]
        });
    } catch (error) {
        console.error('Get Single Transaction Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to retrieve transaction.'
        });
    }
}

/**
 * Add a new transaction
 * POST /api/transactions
 */
async function createTransaction(req, res) {
    try {
        const userId = req.user.id;
        const { category_id, amount, transaction_type, description, transaction_date } = req.body;

        // Validation
        const parsedAmount = parseFloat(amount);
        if (isNaN(parsedAmount) || parsedAmount <= 0) {
            return res.status(400).json({
                success: false,
                message: 'Amount must be a positive number greater than 0.'
            });
        }

        if (!['Income', 'Expense'].includes(transaction_type)) {
            return res.status(400).json({
                success: false,
                message: 'Transaction type must be either "Income" or "Expense".'
            });
        }

        if (!transaction_date) {
            return res.status(400).json({
                success: false,
                message: 'Transaction date is required.'
            });
        }

        let parsedCategoryId = category_id ? parseInt(category_id, 10) : null;
        if (parsedCategoryId) {
            // Check category exists and belongs to user
            const [catCheck] = await pool.query(
                'SELECT category_id, category_type FROM categories WHERE category_id = ? AND user_id = ?',
                [parsedCategoryId, userId]
            );
            if (catCheck.length === 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Selected category does not exist or does not belong to you.'
                });
            }
        }

        const trimmedDesc = description ? description.trim().substring(0, 225) : '';

        const [result] = await pool.query(
            `INSERT INTO transactions (user_id, category_id, amount, transaction_type, description, transaction_date)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [userId, parsedCategoryId, parsedAmount.toFixed(2), transaction_type, trimmedDesc, transaction_date]
        );

        return res.status(201).json({
            success: true,
            message: 'Transaction recorded successfully.',
            transaction: {
                transaction_id: result.insertId,
                user_id: userId,
                category_id: parsedCategoryId,
                amount: parsedAmount.toFixed(2),
                transaction_type,
                description: trimmedDesc,
                transaction_date
            }
        });
    } catch (error) {
        console.error('Create Transaction Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to create transaction.'
        });
    }
}

/**
 * Update an existing transaction
 * PUT /api/transactions/:id
 */
async function updateTransaction(req, res) {
    try {
        const userId = req.user.id;
        const transactionId = parseInt(req.params.id, 10);
        const { category_id, amount, transaction_type, description, transaction_date } = req.body;

        if (!transactionId) {
            return res.status(400).json({ success: false, message: 'Invalid transaction ID.' });
        }

        // Verify transaction ownership
        const [existing] = await pool.query(
            'SELECT transaction_id FROM transactions WHERE transaction_id = ? AND user_id = ?',
            [transactionId, userId]
        );

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Transaction not found or unauthorized.'
            });
        }

        const parsedAmount = parseFloat(amount);
        if (isNaN(parsedAmount) || parsedAmount <= 0) {
            return res.status(400).json({
                success: false,
                message: 'Amount must be a positive number greater than 0.'
            });
        }

        if (!['Income', 'Expense'].includes(transaction_type)) {
            return res.status(400).json({
                success: false,
                message: 'Transaction type must be "Income" or "Expense".'
            });
        }

        if (!transaction_date) {
            return res.status(400).json({
                success: false,
                message: 'Transaction date is required.'
            });
        }

        let parsedCategoryId = category_id ? parseInt(category_id, 10) : null;
        if (parsedCategoryId) {
            const [catCheck] = await pool.query(
                'SELECT category_id FROM categories WHERE category_id = ? AND user_id = ?',
                [parsedCategoryId, userId]
            );
            if (catCheck.length === 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Selected category does not exist.'
                });
            }
        }

        const trimmedDesc = description ? description.trim().substring(0, 225) : '';

        await pool.query(
            `UPDATE transactions 
             SET category_id = ?, amount = ?, transaction_type = ?, description = ?, transaction_date = ?
             WHERE transaction_id = ? AND user_id = ?`,
            [parsedCategoryId, parsedAmount.toFixed(2), transaction_type, trimmedDesc, transaction_date, transactionId, userId]
        );

        return res.json({
            success: true,
            message: 'Transaction updated successfully.'
        });
    } catch (error) {
        console.error('Update Transaction Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to update transaction.'
        });
    }
}

/**
 * Delete transaction
 * DELETE /api/transactions/:id
 */
async function deleteTransaction(req, res) {
    try {
        const userId = req.user.id;
        const transactionId = parseInt(req.params.id, 10);

        if (!transactionId) {
            return res.status(400).json({ success: false, message: 'Invalid transaction ID.' });
        }

        const [existing] = await pool.query(
            'SELECT transaction_id FROM transactions WHERE transaction_id = ? AND user_id = ?',
            [transactionId, userId]
        );

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Transaction not found or unauthorized.'
            });
        }

        await pool.query(
            'DELETE FROM transactions WHERE transaction_id = ? AND user_id = ?',
            [transactionId, userId]
        );

        return res.json({
            success: true,
            message: 'Transaction deleted successfully.'
        });
    } catch (error) {
        console.error('Delete Transaction Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to delete transaction.'
        });
    }
}

/**
 * Export all transactions to CSV
 * GET /api/transactions/export/csv
 */
async function exportCsv(req, res) {
    try {
        const userId = req.user.id;
        const [rows] = await pool.query(
            `SELECT 
                t.transaction_id,
                DATE_FORMAT(t.transaction_date, '%Y-%m-%d') AS date,
                t.transaction_type AS type,
                COALESCE(c.category_name, 'Uncategorized') AS category,
                COALESCE(t.description, '') AS description,
                t.amount
            FROM transactions t
            LEFT JOIN categories c ON t.category_id = c.category_id
            WHERE t.user_id = ?
            ORDER BY t.transaction_date DESC, t.transaction_id DESC`,
            [userId]
        );

        // Build CSV string
        let csv = 'Transaction ID,Date,Type,Category,Description,Amount\n';
        for (const row of rows) {
            const cleanDesc = `"${row.description.replace(/"/g, '""')}"`;
            const cleanCat = `"${row.category.replace(/"/g, '""')}"`;
            csv += `${row.transaction_id},${row.date},${row.type},${cleanCat},${cleanDesc},${row.amount}\n`;
        }

        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="transactions_${Date.now()}.csv"`);
        return res.status(200).send(csv);
    } catch (error) {
        console.error('Export CSV Error:', error);
        return res.status(500).json({
            success: false,
            message: 'Failed to export CSV.'
        });
    }
}

module.exports = {
    getTransactions,
    getTransactionById,
    createTransaction,
    updateTransaction,
    deleteTransaction,
    exportCsv
};

