-- =======================================================
-- Sample Data for Personal Expense Tracker Management System
-- Demo Credentials:
-- Email: demo@expensetracker.com
-- Password: password123
-- =======================================================

USE expense_tracker_db;

-- Insert Demo User
INSERT INTO users (id, name, email, password) VALUES
(1, 'Alex Morgan', 'demo@expensetracker.com', '$2b$10$FFqy79tqUoZtep69q6Sl3.1DZR.EZc3HNacrgEJgtggxInutp0rKS')
ON DUPLICATE KEY UPDATE name='Alex Morgan';

-- Insert Sample Categories for User 1
INSERT INTO categories (category_id, user_id, category_name, category_type) VALUES
-- Expense Categories
(1, 1, 'Food & Dining', 'Expense'),
(2, 1, 'Transportation', 'Expense'),
(3, 1, 'Shopping', 'Expense'),
(4, 1, 'Entertainment', 'Expense'),
(5, 1, 'Healthcare', 'Expense'),
(6, 1, 'Education', 'Expense'),
(7, 1, 'Housing & Utilities', 'Expense'),
-- Income Categories
(8, 1, 'Salary', 'Income'),
(9, 1, 'Freelancing', 'Income'),
(10, 1, 'Investments', 'Income'),
(11, 1, 'Other Income', 'Income')
ON DUPLICATE KEY UPDATE category_name=VALUES(category_name);

-- Insert Sample Budgets (November 2026 and surrounding months)
INSERT INTO budgets (user_id, amount, month, year) VALUES
(1, 4500.00, 11, 2026),
(1, 4200.00, 10, 2026),
(1, 4000.00, 9, 2026)
ON DUPLICATE KEY UPDATE amount=VALUES(amount);

-- Insert Sample Transactions
INSERT INTO transactions (user_id, category_id, amount, transaction_type, description, transaction_date) VALUES
-- Incomes for Nov 2026
(1, 8, 5500.00, 'Income', 'Monthly Tech Corp Salary', '2026-11-01'),
(1, 9, 850.00, 'Income', 'UI/UX Redesign Client Project', '2026-11-04'),

-- Expenses for Nov 2026
(1, 7, 1200.00, 'Expense', 'Apartment Rent & Water Bill', '2026-11-02'),
(1, 1, 145.50, 'Expense', 'Weekly Grocery Shopping at Whole Foods', '2026-11-02'),
(1, 2, 45.00, 'Expense', 'Metro Pass & Uber ride', '2026-11-03'),
(1, 4, 38.00, 'Expense', 'Cinema tickets & streaming subscription', '2026-11-03'),
(1, 1, 62.80, 'Expense', 'Dinner with team', '2026-11-05'),
(1, 3, 120.00, 'Expense', 'New ergonomic desk chair accessories', '2026-11-05'),
(1, 5, 80.00, 'Expense', 'Dental checkup & vitamins', '2026-11-06'),

-- Previous Month Incomes and Expenses (October 2026)
(1, 8, 5500.00, 'Income', 'Monthly Salary', '2026-10-01'),
(1, 9, 1200.00, 'Income', 'Mobile App Development Milestone', '2026-10-15'),
(1, 7, 1200.00, 'Expense', 'October Rent', '2026-10-02'),
(1, 1, 580.00, 'Expense', 'Groceries & Dining October', '2026-10-12'),
(1, 2, 160.00, 'Expense', 'Fuel & Commute', '2026-10-18'),
(1, 3, 340.00, 'Expense', 'Autumn clothing & shoes', '2026-10-22'),
(1, 6, 250.00, 'Expense', 'Fullstack Web Development Masterclass', '2026-10-25');

