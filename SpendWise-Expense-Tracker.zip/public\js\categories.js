/**
 * SpendWise - Category Management Controller
 */

let categoriesList = [];
let currentFilterType = 'All';
let currentEditCategoryId = null;
let currentDeleteCategoryId = null;

document.addEventListener('DOMContentLoaded', async () => {
    const user = await checkAuthAndSetUser();
    if (!user) return;

    await loadCategories();
    setupCategoryTabs();
    setupAddCategoryModal();
    setupEditCategoryModal();
    setupDeleteCategoryModal();
});

/**
 * Load categories from backend
 */
async function loadCategories() {
    try {
        const data = await API.get('/api/categories');
        if (!data.success) throw new Error(data.message);

        categoriesList = data.categories || [];
        renderCategoryList();
    } catch (error) {
        console.error('Failed to load categories:', error);
        showToast('Error loading categories', 'error');
    }
}

/**
 * Filter tabs: All, Expense, Income
 */
function setupCategoryTabs() {
    const tabs = document.querySelectorAll('.category-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            currentFilterType = tab.dataset.type;
            renderCategoryList();
        });
    });
}

/**
 * Render category cards/table
 */
function renderCategoryList() {
    const grid = document.getElementById('categoriesGrid');
    const emptyState = document.getElementById('categoriesEmptyState');
    if (!grid) return;

    grid.innerHTML = '';

    const filtered = categoriesList.filter(c => {
        if (currentFilterType === 'All') return true;
        return c.category_type === currentFilterType;
    });

    if (filtered.length === 0) {
        if (emptyState) emptyState.style.display = 'block';
        return;
    } else {
        if (emptyState) emptyState.style.display = 'none';
    }

    filtered.forEach(cat => {
        const isIncome = cat.category_type === 'Income';
        const badgeClass = isIncome ? 'badge-income' : 'badge-expense';
        const iconName = isIncome ? 'fa-arrow-trend-up' : 'fa-tag';

        const card = document.createElement('div');
        card.className = 'card category-item-card';
        card.style.position = 'relative';

        card.innerHTML = `
            <div style="display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 1rem;">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <div style="width: 40px; height: 40px; border-radius: var(--radius-md); background-color: ${isIncome ? 'var(--success-light)' : 'var(--danger-light)'}; color: ${isIncome ? 'var(--success)' : 'var(--danger)'}; display: flex; align-items: center; justify-content: center; font-size: 1.1rem;">
                        <i class="fa-solid ${iconName}"></i>
                    </div>
                    <div>
                        <h4 style="font-size: 1rem; color: var(--navy-900); margin-bottom: 0.15rem;">${cat.category_name}</h4>
                        <span class="badge ${badgeClass}">${cat.category_type}</span>
                    </div>
                </div>
                <div style="display: flex; gap: 0.25rem;">
                    <button class="btn-icon edit-cat-btn" data-id="${cat.category_id}" title="Edit Category">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                    <button class="btn-icon danger delete-cat-btn" data-id="${cat.category_id}" title="Delete Category">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                </div>
            </div>

            <div style="background-color: var(--bg-muted); border-radius: var(--radius-md); padding: 0.75rem 1rem; display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Transactions</div>
                    <div style="font-size: 0.95rem; font-weight: 700; color: var(--navy-900);" class="tabular-nums">${cat.transaction_count}</div>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Total Volume</div>
                    <div style="font-size: 0.95rem; font-weight: 700; color: ${isIncome ? 'var(--success)' : 'var(--danger)'};" class="tabular-nums">
                        ${formatCurrency(cat.total_spent)}
                    </div>
                </div>
            </div>
        `;

        card.querySelector('.edit-cat-btn').addEventListener('click', () => openEditCategoryModal(cat));
        card.querySelector('.delete-cat-btn').addEventListener('click', () => openDeleteCategoryModal(cat));

        grid.appendChild(card);
    });
}

/**
 * Add Category Modal
 */
function setupAddCategoryModal() {
    const modal = document.getElementById('addCategoryModal');
    const openBtns = document.querySelectorAll('.btn-open-add-category');
    const closeBtn = document.getElementById('closeAddCatModalBtn');
    const cancelBtn = document.getElementById('cancelAddCatModalBtn');
    const form = document.getElementById('addCategoryForm');

    openBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            if (modal) modal.classList.add('active');
        });
    });

    const closeModal = () => {
        if (modal) modal.classList.remove('active');
        if (form) form.reset();
    };

    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const category_name = document.getElementById('addCategoryName').value.trim();
            const category_type = document.getElementById('addCategoryType').value;

            if (!category_name) {
                showToast('Category name is required', 'warning');
                return;
            }

            try {
                const res = await API.post('/api/categories', { category_name, category_type });
                if (res.success) {
                    showToast('Category created successfully!', 'success');
                    closeModal();
                    await loadCategories();
                }
            } catch (err) {
                showToast(err.message || 'Failed to create category', 'error');
            }
        });
    }
}

/**
 * Edit Category Modal
 */
function setupEditCategoryModal() {
    const modal = document.getElementById('editCategoryModal');
    const closeBtn = document.getElementById('closeEditCatModalBtn');
    const cancelBtn = document.getElementById('cancelEditCatModalBtn');
    const form = document.getElementById('editCategoryForm');

    const closeModal = () => {
        if (modal) modal.classList.remove('active');
        if (form) form.reset();
        currentEditCategoryId = null;
    };

    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            if (!currentEditCategoryId) return;

            const category_name = document.getElementById('editCategoryName').value.trim();
            const category_type = document.getElementById('editCategoryType').value;

            if (!category_name) {
                showToast('Category name is required', 'warning');
                return;
            }

            try {
                const res = await API.put(`/api/categories/${currentEditCategoryId}`, {
                    category_name,
                    category_type
                });

                if (res.success) {
                    showToast('Category updated successfully!', 'success');
                    closeModal();
                    await loadCategories();
                }
            } catch (err) {
                showToast(err.message || 'Failed to update category', 'error');
            }
        });
    }
}

function openEditCategoryModal(cat) {
    currentEditCategoryId = cat.category_id;
    document.getElementById('editCategoryName').value = cat.category_name;
    document.getElementById('editCategoryType').value = cat.category_type;

    const modal = document.getElementById('editCategoryModal');
    if (modal) modal.classList.add('active');
}

/**
 * Delete Category Confirmation Modal
 */
function setupDeleteCategoryModal() {
    const modal = document.getElementById('deleteCategoryModal');
    const cancelBtn = document.getElementById('cancelDeleteCatBtn');
    const confirmBtn = document.getElementById('confirmDeleteCatBtn');

    const closeModal = () => {
        if (modal) modal.classList.remove('active');
        currentDeleteCategoryId = null;
    };

    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
    }

    if (confirmBtn) {
        confirmBtn.addEventListener('click', async () => {
            if (!currentDeleteCategoryId) return;
            try {
                const res = await API.delete(`/api/categories/${currentDeleteCategoryId}`);
                if (res.success) {
                    showToast(res.message || 'Category deleted successfully', 'success');
                    closeModal();
                    await loadCategories();
                }
            } catch (err) {
                showToast(err.message || 'Failed to delete category', 'error');
            }
        });
    }
}

function openDeleteCategoryModal(cat) {
    currentDeleteCategoryId = cat.category_id;
    const nameEl = document.getElementById('deleteCategoryTargetName');
    if (nameEl) nameEl.textContent = cat.category_name;

    const modal = document.getElementById('deleteCategoryModal');
    if (modal) modal.classList.add('active');
}

