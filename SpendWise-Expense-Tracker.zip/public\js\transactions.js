/**
 * SpendWise - Transactions Management Controller
 */

let allCategories = [];
let currentDeleteId = null;
let currentEditId = null;

document.addEventListener('DOMContentLoaded', async () => {
    const user = await checkAuthAndSetUser();
    if (!user) return;

    await loadCategories();
    await loadTransactions();

    setupFilterListeners();
    setupAddTransactionModal();
    setupEditTransactionModal();
    setupDeleteModal();
    setupCsvExport();
});

/**
 * Load categories for filters and dropdowns
 */
async function loadCategories() {
    try {
        const res = await API.get('/api/categories');
        if (res.success) {
            allCategories = res.categories || [];

            // Populate category filter dropdown
            const filterCat = document.getElementById('filterCategory');
            if (filterCat) {
                filterCat.innerHTML = '<option value="">All Categories</option>';
                allCategories.forEach(c => {
                    const opt = document.createElement('option');
                    opt.value = c.category_id;
                    opt.textContent = `${c.category_name} (${c.category_type})`;
                    filterCat.appendChild(opt);
                });
            }

            // Populate Add Modal categories
            updateModalCategoryOptions('addTransactionType', 'addTransactionCategory');
            updateModalCategoryOptions('editTransactionType', 'editTransactionCategory');
        }
    } catch (e) {
        console.error('Failed to load categories:', e);
    }
}

/**
 * Update Category dropdown in modal based on type selected
 */
function updateModalCategoryOptions(typeSelectId, catSelectId, selectedCatId = null) {
    const typeSelect = document.getElementById(typeSelectId);
    const catSelect = document.getElementById(catSelectId);
    if (!typeSelect || !catSelect) return;

    const currentType = typeSelect.value;
    catSelect.innerHTML = '<option value="">Select Category</option>';

    const filtered = allCategories.filter(c => c.category_type === currentType);
    filtered.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c.category_id;
        opt.textContent = c.category_name;
        if (selectedCatId && String(c.category_id) === String(selectedCatId)) {
            opt.selected = true;
        }
        catSelect.appendChild(opt);
    });
}

/**
 * Load and render transactions
 */
async function loadTransactions() {
    try {
        const search = document.getElementById('filterSearch')?.value.trim() || '';
        const type = document.getElementById('filterType')?.value || '';
        const categoryId = document.getElementById('filterCategory')?.value || '';
        const startDate = document.getElementById('filterStartDate')?.value || '';
        const endDate = document.getElementById('filterEndDate')?.value || '';

        const params = new URLSearchParams();
        if (search) params.append('search', search);
        if (type) params.append('type', type);
        if (categoryId) params.append('categoryId', categoryId);
        if (startDate) params.append('startDate', startDate);
        if (endDate) params.append('endDate', endDate);

        const data = await API.get(`/api/transactions?${params.toString()}`);
        if (!data.success) throw new Error(data.message);

        // Update Summary Cards
        const filteredCountEl = document.getElementById('filteredCount');
        const filteredIncomeEl = document.getElementById('filteredIncome');
        const filteredExpenseEl = document.getElementById('filteredExpense');
        const filteredBalanceEl = document.getElementById('filteredBalance');

        if (filteredCountEl) filteredCountEl.textContent = data.totalCount;
        if (filteredIncomeEl) filteredIncomeEl.textContent = formatCurrency(data.summary.totalIncome);
        if (filteredExpenseEl) filteredExpenseEl.textContent = formatCurrency(data.summary.totalExpense);
        if (filteredBalanceEl) {
            filteredBalanceEl.textContent = formatCurrency(data.summary.netBalance);
            filteredBalanceEl.style.color = data.summary.netBalance < 0 ? 'var(--danger)' : 'var(--navy-900)';
        }

        renderTransactionTable(data.transactions);
    } catch (error) {
        console.error('Failed to load transactions:', error);
        showToast('Error loading transactions', 'error');
    }
}

/**
 * Render transaction rows
 */
function renderTransactionTable(transactions) {
    const tbody = document.getElementById('transactionsTableBody');
    const emptyState = document.getElementById('transactionsEmptyState');
    if (!tbody) return;

    tbody.innerHTML = '';

    if (!transactions || transactions.length === 0) {
        if (emptyState) emptyState.style.display = 'block';
        return;
    } else {
        if (emptyState) emptyState.style.display = 'none';
    }

    transactions.forEach(t => {
        const isIncome = t.transaction_type === 'Income';
        const sign = isIncome ? '+' : '-';
        const amountClass = isIncome ? 'amount-income' : 'amount-expense';
        const badgeClass = isIncome ? 'badge-income' : 'badge-expense';

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td class="tabular-nums" style="font-weight: 500;">${formatDate(t.transaction_date)}</td>
            <td>
                <span class="badge ${badgeClass}">
                    <i class="fa-solid ${isIncome ? 'fa-arrow-down-left' : 'fa-arrow-up-right'}"></i>
                    ${t.transaction_type}
                </span>
            </td>
            <td><span class="badge badge-neutral">${t.category_name || 'Uncategorized'}</span></td>
            <td style="color: var(--text-secondary); max-width: 280px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                ${t.description || '—'}
            </td>
            <td class="${amountClass} tabular-nums" style="text-align: right; font-size: 0.95rem;">
                ${sign}${formatCurrency(t.amount)}
            </td>
            <td style="text-align: right; white-space: nowrap;">
                <button class="btn-icon edit-btn" data-id="${t.transaction_id}" title="Edit Transaction">
                    <i class="fa-solid fa-pen-to-square"></i>
                </button>
                <button class="btn-icon danger delete-btn" data-id="${t.transaction_id}" title="Delete Transaction">
                    <i class="fa-solid fa-trash-can"></i>
                </button>
            </td>
        `;

        // Attach action handlers
        tr.querySelector('.edit-btn').addEventListener('click', () => openEditModal(t.transaction_id));
        tr.querySelector('.delete-btn').addEventListener('click', () => openDeleteModal(t.transaction_id));

        tbody.appendChild(tr);
    });
}

/**
 * Filter event listeners
 */
function setupFilterListeners() {
    const searchInput = document.getElementById('filterSearch');
    const typeSelect = document.getElementById('filterType');
    const categorySelect = document.getElementById('filterCategory');
    const startDateInput = document.getElementById('filterStartDate');
    const endDateInput = document.getElementById('filterEndDate');
    const resetBtn = document.getElementById('resetFiltersBtn');

    let debounceTimer;
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => loadTransactions(), 300);
        });
    }

    [typeSelect, categorySelect, startDateInput, endDateInput].forEach(el => {
        if (el) el.addEventListener('change', () => loadTransactions());
    });

    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            if (searchInput) searchInput.value = '';
            if (typeSelect) typeSelect.value = '';
            if (categorySelect) categorySelect.value = '';
            if (startDateInput) startDateInput.value = '';
            if (endDateInput) endDateInput.value = '';
            loadTransactions();
            showToast('Filters cleared', 'info');
        });
    }
}

/**
 * Add Transaction Modal
 */
function setupAddTransactionModal() {
    const modal = document.getElementById('addTransactionModal');
    const openBtns = document.querySelectorAll('.btn-open-add');
    const closeBtn = document.getElementById('closeAddModalBtn');
    const cancelBtn = document.getElementById('cancelAddModalBtn');
    const form = document.getElementById('addTransactionForm');
    const typeSelect = document.getElementById('addTransactionType');
    const dateInput = document.getElementById('addTransactionDate');

    if (dateInput) dateInput.value = new Date().toISOString().split('T')[0];

    if (typeSelect) {
        typeSelect.addEventListener('change', () => {
            updateModalCategoryOptions('addTransactionType', 'addTransactionCategory');
        });
    }

    openBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            if (modal) modal.classList.add('active');
        });
    });

    const closeModal = () => {
        if (modal) modal.classList.remove('active');
        if (form) form.reset();
        if (dateInput) dateInput.value = new Date().toISOString().split('T')[0];
        updateModalCategoryOptions('addTransactionType', 'addTransactionCategory');
    };

    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);

    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const amount = document.getElementById('addTransactionAmount').value;
            const transaction_type = document.getElementById('addTransactionType').value;
            const category_id = document.getElementById('addTransactionCategory').value;
            const transaction_date = document.getElementById('addTransactionDate').value;
            const description = document.getElementById('addTransactionDescription').value;

            if (!amount || parseFloat(amount) <= 0) {
                showToast('Please enter a valid amount greater than 0', 'warning');
                return;
            }

            try {
                const res = await API.post('/api/transactions', {
                    amount,
                    transaction_type,
                    category_id: category_id || null,
                    transaction_date,
                    description
                });

                if (res.success) {
                    showToast('Transaction added successfully!', 'success');
                    closeModal();
                    await loadTransactions();
                }
            } catch (err) {
                showToast(err.message || 'Failed to add transaction', 'error');
            }
        });
    }
}

/**
 * Edit Transaction Modal
 */
function setupEditTransactionModal() {
    const modal = document.getElementById('editTransactionModal');
    const closeBtn = document.getElementById('closeEditModalBtn');
    const cancelBtn = document.getElementById('cancelEditModalBtn');
    const form = document.getElementById('editTransactionForm');
    const typeSelect = document.getElementById('editTransactionType');

    if (typeSelect) {
        typeSelect.addEventListener('change', () => {
            updateModalCategoryOptions('editTransactionType', 'editTransactionCategory');
        });
    }

    const closeModal = () => {
        if (modal) modal.classList.remove('active');
        if (form) form.reset();
        currentEditId = null;
    };

    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);

    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            if (!currentEditId) return;

            const amount = document.getElementById('editTransactionAmount').value;
            const transaction_type = document.getElementById('editTransactionType').value;
            const category_id = document.getElementById('editTransactionCategory').value;
            const transaction_date = document.getElementById('editTransactionDate').value;
            const description = document.getElementById('editTransactionDescription').value;

            if (!amount || parseFloat(amount) <= 0) {
                showToast('Please enter a valid amount greater than 0', 'warning');
                return;
            }

            try {
                const res = await API.put(`/api/transactions/${currentEditId}`, {
                    amount,
                    transaction_type,
                    category_id: category_id || null,
                    transaction_date,
                    description
                });

                if (res.success) {
                    showToast('Transaction updated successfully!', 'success');
                    closeModal();
                    await loadTransactions();
                }
            } catch (err) {
                showToast(err.message || 'Failed to update transaction', 'error');
            }
        });
    }
}

async function openEditModal(id) {
    currentEditId = id;
    const modal = document.getElementById('editTransactionModal');
    try {
        const res = await API.get(`/api/transactions/${id}`);
        if (res.success && res.transaction) {
            const t = res.transaction;
            document.getElementById('editTransactionAmount').value = t.amount;
            document.getElementById('editTransactionType').value = t.transaction_type;
            updateModalCategoryOptions('editTransactionType', 'editTransactionCategory', t.category_id);
            document.getElementById('editTransactionDate').value = t.transaction_date;
            document.getElementById('editTransactionDescription').value = t.description || '';

            if (modal) modal.classList.add('active');
        }
    } catch (e) {
        showToast('Failed to load transaction details', 'error');
    }
}

/**
 * Delete Confirmation Modal
 */
function setupDeleteModal() {
    const modal = document.getElementById('deleteConfirmModal');
    const cancelBtn = document.getElementById('cancelDeleteBtn');
    const confirmBtn = document.getElementById('confirmDeleteBtn');

    const closeModal = () => {
        if (modal) modal.classList.remove('active');
        currentDeleteId = null;
    };

    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
    }

    if (confirmBtn) {
        confirmBtn.addEventListener('click', async () => {
            if (!currentDeleteId) return;
            try {
                const res = await API.delete(`/api/transactions/${currentDeleteId}`);
                if (res.success) {
                    showToast('Transaction deleted successfully', 'success');
                    closeModal();
                    await loadTransactions();
                }
            } catch (err) {
                showToast(err.message || 'Failed to delete transaction', 'error');
            }
        });
    }
}

function openDeleteModal(id) {
    currentDeleteId = id;
    const modal = document.getElementById('deleteConfirmModal');
    if (modal) modal.classList.add('active');
}

/**
 * CSV Export Trigger
 */
function setupCsvExport() {
    const exportBtn = document.getElementById('exportCsvBtn');
    if (exportBtn) {
        exportBtn.addEventListener('click', () => {
            window.location.href = '/api/transactions/export/csv';
            showToast('Downloading transactions CSV...', 'info');
        });
    }
}

