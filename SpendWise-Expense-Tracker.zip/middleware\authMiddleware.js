/**
 * Authentication Middleware
 * Checks if user is logged in via express-session
 */
function requireAuth(req, res, next) {
    if (req.session && req.session.user) {
        req.user = req.session.user;
        return next();
    }
    
    // For API requests, return 401 JSON
    if (req.xhr || req.headers.accept?.includes('json') || req.path.startsWith('/api/')) {
        return res.status(401).json({
            success: false,
            message: 'Authentication required. Please log in to continue.'
        });
    }

    // For web page requests, redirect to login page
    return res.redirect('/login.html');
}

module.exports = {
    requireAuth
};

