const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');

// Default starter categories for newly registered users
const DEFAULT_CATEGORIES = [
    { name: 'Food & Dining', type: 'Expense' },
    { name: 'Transportation', type: 'Expense' },
    { name: 'Shopping', type: 'Expense' },
    { name: 'Entertainment', type: 'Expense' },
    { name: 'Healthcare', type: 'Expense' },
    { name: 'Education', type: 'Expense' },
    { name: 'Housing & Utilities', type: 'Expense' },
    { name: 'Salary', type: 'Income' },
    { name: 'Freelancing', type: 'Income' },
    { name: 'Investments', type: 'Income' },
    { name: 'Other Income', type: 'Income' }
];

/**
 * Register a new user
 * POST /api/auth/register
 */
async function register(req, res) {
    try {
        const { name, email, password } = req.body;

        // Validation
        if (!name || !email || !password) {
            return res.status(400).json({
                success: false,
                message: 'All fields (name, email, password) are required.'
            });
        }

        const trimmedName = name.trim();
        const trimmedEmail = email.trim().toLowerCase();

        if (trimmedName.length < 2 || trimmedName.length > 50) {
            return res.status(400).json({
                success: false,
                message: 'Name must be between 2 and 50 characters.'
            });
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(trimmedEmail)) {
            return res.status(400).json({
                success: false,
                message: 'Please provide a valid email address.'
            });
        }

        if (password.length < 6) {
            return res.status(400).json({
                success: false,
                message: 'Password must be at least 6 characters long.'
            });
        }

        // Check if user already exists
        const [existing] = await pool.query(
            'SELECT id FROM users WHERE email = ?',
            [trimmedEmail]
        );

        if (existing.length > 0) {
            return res.status(409).json({
                success: false,
                message: 'An account with this email already exists.'
            });
        }

        // Hash password
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        // Insert user
        const [result] = await pool.query(
            'INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
            [trimmedName, trimmedEmail, hashedPassword]
        );

        const newUserId = result.insertId;

        // Seed default categories for this user
        for (const cat of DEFAULT_CATEGORIES) {
            await pool.query(
                'INSERT INTO categories (user_id, category_name, category_type) VALUES (?, ?, ?)',
                [newUserId, cat.name, cat.type]
            );
        }

        // Automatically log user in via session
        req.session.user = {
            id: newUserId,
            name: trimmedName,
            email: trimmedEmail
        };

        return res.status(201).json({
            success: true,
            message: 'Registration successful! Welcome to SpendWise.',
            user: {
                id: newUserId,
                name: trimmedName,
                email: trimmedEmail
            }
        });
    } catch (error) {
        console.error('Registration Error:', error);
        return res.status(500).json({
            success: false,
            message: 'An error occurred during registration. Please try again.'
        });
    }
}

/**
 * Log in an existing user
 * POST /api/auth/login
 */
async function login(req, res) {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Email and password are required.'
            });
        }

        const trimmedEmail = email.trim().toLowerCase();

        // Query user from MySQL
        const [rows] = await pool.query(
            'SELECT id, name, email, password FROM users WHERE email = ?',
            [trimmedEmail]
        );

        if (rows.length === 0) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password.'
            });
        }

        const user = rows[0];

        // Compare password hash
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password.'
            });
        }

        // Establish session
        req.session.user = {
            id: user.id,
            name: user.name,
            email: user.email
        };

        return res.json({
            success: true,
            message: 'Login successful. Redirecting to dashboard...',
            user: {
                id: user.id,
                name: user.name,
                email: user.email
            }
        });
    } catch (error) {
        console.error('Login Error:', error);
        return res.status(500).json({
            success: false,
            message: 'An error occurred during login. Please try again.'
        });
    }
}

/**
 * Log out user
 * POST /api/auth/logout
 */
function logout(req, res) {
    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err);
            return res.status(500).json({
                success: false,
                message: 'Unable to log out at this moment.'
            });
        }
        res.clearCookie('connect.sid');
        return res.json({
            success: true,
            message: 'Logged out successfully.'
        });
    });
}

/**
 * Get current session user
 * GET /api/auth/me
 */
function getMe(req, res) {
    if (req.session && req.session.user) {
        return res.json({
            success: true,
            user: req.session.user
        });
    }
    return res.status(401).json({
        success: false,
        message: 'No active session.'
    });
}

module.exports = {
    register,
    login,
    logout,
    getMe
};

