/**
 * SpendWise - Spending Reports & Analytics Controller
 */

let categoryChartInstance = null;
let monthlyBarChartInstance = null;
let currentPeriod = 'month';
let selectedYear = new Date().getFullYear();

document.addEventListener('DOMContentLoaded', async () => {
    const user = await checkAuthAndSetUser();
    if (!user) return;

    setupPeriodFilters();
    setupYearSelector();
    setupPrintButton();

    await loadAllReports();
});

/**
 * Setup period tabs: Today, Week, Month, Year, Custom
 */
function setupPeriodFilters() {
    const tabs = document.querySelectorAll('.period-tab');
    const customRangeBox = document.getElementById('customDateRangeBox');
    const applyCustomBtn = document.getElementById('applyCustomRangeBtn');

    tabs.forEach(tab => {
        tab.addEventListener('click', async () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            currentPeriod = tab.dataset.period;

            if (currentPeriod === 'custom') {
                if (customRangeBox) customRangeBox.style.display = 'flex';
            } else {
                if (customRangeBox) customRangeBox.style.display = 'none';
                await loadAllReports();
            }
        });
    });

    if (applyCustomBtn) {
        applyCustomBtn.addEventListener('click', async () => {
            await loadAllReports();
        });
    }
}

/**
 * Setup Year dropdown for Annual trends
 */
function setupYearSelector() {
    const yearSelect = document.getElementById('reportYearSelect');
    if (!yearSelect) return;

    const currentYr = new Date().getFullYear();
    yearSelect.innerHTML = '';
    for (let y = currentYr - 2; y <= currentYr + 2; y++) {
        const opt = document.createElement('option');
        opt.value = y;
        opt.textContent = y;
        if (y === selectedYear) opt.selected = true;
        yearSelect.appendChild(opt);
    }

    yearSelect.addEventListener('change', async (e) => {
        selectedYear = parseInt(e.target.value, 10);
        await loadMonthlyTrendReport();
    });
}

/**
 * Print Report
 */
function setupPrintButton() {
    const printBtn = document.getElementById('printReportBtn');
    if (printBtn) {
        printBtn.addEventListener('click', () => {
            window.print();
        });
    }
}

/**
 * Load all report sections
 */
async function loadAllReports() {
    await loadSummaryKPIs();
    await loadCategoryBreakdownReport();
    await loadMonthlyTrendReport();
}

/**
 * Load Summary KPI cards for active period
 */
async function loadSummaryKPIs() {
    try {
        let endpoint = `/api/reports/summary?period=${currentPeriod}`;
        if (currentPeriod === 'custom') {
            const start = document.getElementById('reportStartDate')?.value;
            const end = document.getElementById('reportEndDate')?.value;
            if (start && end) {
                endpoint += `&startDate=${start}&endDate=${end}`;
            }
        }

        const data = await API.get(endpoint);
        if (!data.success) throw new Error(data.message);

        const s = data.summary;
        const incomeEl = document.getElementById('reportTotalIncome');
        const expenseEl = document.getElementById('reportTotalExpense');
        const savingsEl = document.getElementById('reportNetSavings');
        const rateEl = document.getElementById('reportSavingsRate');

        if (incomeEl) incomeEl.textContent = formatCurrency(s.totalIncome);
        if (expenseEl) expenseEl.textContent = formatCurrency(s.totalExpense);
        
        if (savingsEl) {
            savingsEl.textContent = formatCurrency(s.netSavings);
            savingsEl.style.color = s.netSavings < 0 ? 'var(--danger)' : 'var(--navy-900)';
        }

        if (rateEl) {
            rateEl.textContent = `${s.savingsRate}%`;
            rateEl.style.color = s.savingsRate >= 20 ? 'var(--success)' : 'var(--navy-900)';
        }

    } catch (e) {
        console.error('Failed to load summary KPIs:', e);
    }
}

/**
 * Load Category-wise breakdown
 */
async function loadCategoryBreakdownReport() {
    try {
        let endpoint = `/api/reports/category-wise?type=Expense`;
        if (currentPeriod === 'custom') {
            const start = document.getElementById('reportStartDate')?.value;
            const end = document.getElementById('reportEndDate')?.value;
            if (start && end) endpoint += `&startDate=${start}&endDate=${end}`;
        } else if (currentPeriod === 'month') {
            const now = new Date();
            endpoint += `&month=${now.getMonth() + 1}&year=${now.getFullYear()}`;
        } else if (currentPeriod === 'year') {
            endpoint += `&year=${selectedYear}`;
        }

        const data = await API.get(endpoint);
        if (!data.success) throw new Error(data.message);

        renderCategoryChart(data.categories);
        renderCategoryTable(data.categories, data.totalOverall);

    } catch (e) {
        console.error('Failed to load category breakdown:', e);
    }
}

/**
 * Render Category Pie/Doughnut Chart
 */
function renderCategoryChart(categories) {
    const ctx = document.getElementById('reportCategoryChart');
    const emptyNotice = document.getElementById('reportCategoryEmpty');
    if (!ctx) return;

    if (categoryChartInstance) {
        categoryChartInstance.destroy();
    }

    if (!categories || categories.length === 0) {
        ctx.style.display = 'none';
        if (emptyNotice) emptyNotice.style.display = 'flex';
        return;
    } else {
        ctx.style.display = 'block';
        if (emptyNotice) emptyNotice.style.display = 'none';
    }

    const labels = categories.map(c => c.category_name);
    const amounts = categories.map(c => c.total_amount);

    const colors = [
        '#3b82f6', '#10b981', '#f59e0b', '#ec4899',
        '#8b5cf6', '#14b8a6', '#f97316', '#64748b', '#06b6d4'
    ];

    categoryChartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels,
            datasets: [{
                data: amounts,
                backgroundColor: colors.slice(0, amounts.length),
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '60%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 12,
                        padding: 10,
                        font: { family: 'Inter', size: 11 }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return ` ${context.label}: ${formatCurrency(context.raw)}`;
                        }
                    }
                }
            }
        }
    });
}

/**
 * Render Category Table with progress bars
 */
function renderCategoryTable(categories, totalOverall) {
    const tbody = document.getElementById('reportCategoryTableBody');
    if (!tbody) return;

    tbody.innerHTML = '';

    if (!categories || categories.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: var(--text-muted); padding: 2rem;">No expense categories recorded for this period.</td></tr>';
        return;
    }

    categories.forEach(c => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td style="font-weight: 600; color: var(--navy-900);">${c.category_name}</td>
            <td class="tabular-nums" style="text-align: center;">${c.transaction_count}</td>
            <td class="tabular-nums amount-expense" style="text-align: right; font-weight: 600;">
                ${formatCurrency(c.total_amount)}
            </td>
            <td style="width: 30%;">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <div style="flex: 1; height: 8px; background-color: var(--bg-muted); border-radius: 9999px; overflow: hidden;">
                        <div style="width: ${c.percentage}%; height: 100%; background-color: var(--primary); border-radius: 9999px;"></div>
                    </div>
                    <span style="font-size: 0.8125rem; font-weight: 600; width: 45px; text-align: right;" class="tabular-nums">${c.percentage}%</span>
                </div>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

/**
 * Load 12-month Income vs Expense Trend
 */
async function loadMonthlyTrendReport() {
    try {
        const data = await API.get(`/api/reports/monthly?year=${selectedYear}`);
        if (!data.success) throw new Error(data.message);

        renderMonthlyBarChart(data.reports);
        renderMonthlyTable(data.reports);

    } catch (e) {
        console.error('Failed to load monthly trend report:', e);
    }
}

/**
 * Render 12-month bar chart
 */
function renderMonthlyBarChart(reports) {
    const ctx = document.getElementById('reportMonthlyBarChart');
    if (!ctx) return;

    if (monthlyBarChartInstance) {
        monthlyBarChartInstance.destroy();
    }

    const labels = reports.map(r => r.month_name);
    const incomeData = reports.map(r => r.total_income);
    const expenseData = reports.map(r => r.total_expense);

    monthlyBarChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels,
            datasets: [
                {
                    label: 'Income',
                    data: incomeData,
                    backgroundColor: 'rgba(16, 185, 129, 0.85)',
                    borderColor: '#10b981',
                    borderRadius: 6,
                    borderWidth: 1,
                    maxBarThickness: 24
                },
                {
                    label: 'Expense',
                    data: expenseData,
                    backgroundColor: 'rgba(239, 68, 68, 0.85)',
                    borderColor: '#ef4444',
                    borderRadius: 6,
                    borderWidth: 1,
                    maxBarThickness: 24
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { boxWidth: 12, font: { family: 'Inter', size: 12 } }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${formatCurrency(context.raw)}`;
                        }
                    }
                }
            },
            scales: {
                x: { grid: { display: false } },
                y: {
                    beginAtZero: true,
                    ticks: { callback: v => `$${v}` },
                    grid: { color: 'rgba(226, 232, 240, 0.6)' }
                }
            }
        }
    });
}

/**
 * Render 12-month summary table
 */
function renderMonthlyTable(reports) {
    const tbody = document.getElementById('reportMonthlyTableBody');
    if (!tbody) return;

    tbody.innerHTML = '';

    reports.forEach(r => {
        const isPositive = r.net_savings >= 0;
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td style="font-weight: 600; color: var(--navy-900);">${r.month_name} ${r.year}</td>
            <td class="tabular-nums amount-income" style="text-align: right;">${formatCurrency(r.total_income)}</td>
            <td class="tabular-nums amount-expense" style="text-align: right;">${formatCurrency(r.total_expense)}</td>
            <td class="tabular-nums" style="text-align: right; font-weight: 600; color: ${isPositive ? 'var(--navy-900)' : 'var(--danger)'};">
                ${formatCurrency(r.net_savings)}
            </td>
            <td class="tabular-nums" style="text-align: right; font-weight: 600;">
                <span class="badge ${r.savings_rate >= 20 ? 'badge-income' : 'badge-neutral'}">${r.savings_rate}%</span>
            </td>
            <td class="tabular-nums" style="text-align: center;">${r.transaction_count}</td>
        `;
        tbody.appendChild(tr);
    });
}

