/**
 * SpendWise - Monthly Budget Management Controller
 */

const MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
];

let selectedMonth = new Date().getMonth() + 1;
let selectedYear = new Date().getFullYear();
let currentDeleteBudgetId = null;

document.addEventListener('DOMContentLoaded', async () => {
    const user = await checkAuthAndSetUser();
    if (!user) return;

    setupMonthYearSelector();
    await loadCurrentBudget();
    await loadBudgetHistory();
    setupSetBudgetModal();
    setupDeleteBudgetModal();
});

/**
 * Setup Month & Year Pickers
 */
function setupMonthYearSelector() {
    const monthSelect = document.getElementById('selectBudgetMonth');
    const yearSelect = document.getElementById('selectBudgetYear');

    if (monthSelect) {
        monthSelect.innerHTML = '';
        MONTH_NAMES.forEach((name, idx) => {
            const opt = document.createElement('option');
            opt.value = idx + 1;
            opt.textContent = name;
            if (idx + 1 === selectedMonth) opt.selected = true;
            monthSelect.appendChild(opt);
        });

        monthSelect.addEventListener('change', async (e) => {
            selectedMonth = parseInt(e.target.value, 10);
            await loadCurrentBudget();
        });
    }

    if (yearSelect) {
        yearSelect.innerHTML = '';
        const currentYr = new Date().getFullYear();
        for (let y = currentYr - 2; y <= currentYr + 2; y++) {
            const opt = document.createElement('option');
            opt.value = y;
            opt.textContent = y;
            if (y === selectedYear) opt.selected = true;
            yearSelect.appendChild(opt);
        }

        yearSelect.addEventListener('change', async (e) => {
            selectedYear = parseInt(e.target.value, 10);
            await loadCurrentBudget();
        });
    }
}

/**
 * Load budget for the currently selected month and year
 */
async function loadCurrentBudget() {
    try {
        const data = await API.get(`/api/budgets/current?month=${selectedMonth}&year=${selectedYear}`);
        if (!data.success) throw new Error(data.message);

        const b = data.budget;
        const monthTitle = `${MONTH_NAMES[selectedMonth - 1]} ${selectedYear}`;

        const titleEl = document.getElementById('currentBudgetMonthTitle');
        const limitEl = document.getElementById('budgetCardLimit');
        const spentEl = document.getElementById('budgetCardSpent');
        const remainEl = document.getElementById('budgetCardRemaining');
        const pctEl = document.getElementById('budgetCardPercent');
        const barFill = document.getElementById('budgetCardProgressBar');
        const alertBanner = document.getElementById('budgetAlertBanner');

        if (titleEl) titleEl.textContent = monthTitle;
        if (limitEl) limitEl.textContent = b.budget_amount > 0 ? formatCurrency(b.budget_amount) : 'Not Set';
        if (spentEl) spentEl.textContent = formatCurrency(b.total_spent);
        
        if (remainEl) {
            remainEl.textContent = formatCurrency(b.remaining);
            remainEl.style.color = b.remaining < 0 ? 'var(--danger)' : 'var(--navy-900)';
        }

        if (pctEl) pctEl.textContent = b.budget_amount > 0 ? `${b.percentage}%` : '0%';

        if (barFill) {
            const width = Math.min(b.percentage, 100);
            barFill.style.width = `${width}%`;
            barFill.className = `progress-bar-fill ${b.status}`;
        }

        // Alert Banner
        if (alertBanner) {
            if (!data.hasBudget) {
                alertBanner.className = 'card';
                alertBanner.style.backgroundColor = 'var(--primary-light)';
                alertBanner.style.borderColor = 'var(--primary-border)';
                alertBanner.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 0.75rem; color: var(--primary);">
                        <i class="fa-solid fa-circle-info" style="font-size: 1.25rem;"></i>
                        <div>
                            <strong>No Budget Set for ${monthTitle}:</strong> Click "Set Budget" to allocate your monthly spending limit.
                        </div>
                    </div>
                `;
            } else if (b.status === 'exceeded') {
                alertBanner.className = 'card';
                alertBanner.style.backgroundColor = 'var(--danger-light)';
                alertBanner.style.borderColor = 'var(--danger-border)';
                alertBanner.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 0.75rem; color: var(--danger);">
                        <i class="fa-solid fa-circle-exclamation" style="font-size: 1.35rem;"></i>
                        <div>
                            <strong>Budget Exceeded!</strong> You have spent <strong>${formatCurrency(b.total_spent)}</strong>, which is <strong>${formatCurrency(Math.abs(b.remaining))}</strong> over your ${formatCurrency(b.budget_amount)} budget.
                        </div>
                    </div>
                `;
            } else if (b.status === 'warning') {
                alertBanner.className = 'card';
                alertBanner.style.backgroundColor = 'var(--warning-light)';
                alertBanner.style.borderColor = 'var(--warning-border)';
                alertBanner.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 0.75rem; color: var(--warning);">
                        <i class="fa-solid fa-triangle-exclamation" style="font-size: 1.35rem;"></i>
                        <div>
                            <strong>Caution: Approaching Budget Limit!</strong> You have consumed <strong>${b.percentage}%</strong> of your monthly limit. Only <strong>${formatCurrency(b.remaining)}</strong> remaining.
                        </div>
                    </div>
                `;
            } else {
                alertBanner.className = 'card';
                alertBanner.style.backgroundColor = 'var(--success-light)';
                alertBanner.style.borderColor = 'var(--success-border)';
                alertBanner.innerHTML = `
                    <div style="display: flex; align-items: center; gap: 0.75rem; color: var(--success);">
                        <i class="fa-solid fa-circle-check" style="font-size: 1.35rem;"></i>
                        <div>
                            <strong>On Track:</strong> You have used <strong>${b.percentage}%</strong> of your budget. You still have <strong>${formatCurrency(b.remaining)}</strong> to spend comfortably.
                        </div>
                    </div>
                `;
            }
        }

    } catch (e) {
        console.error('Error loading current budget:', e);
        showToast('Failed to load budget data', 'error');
    }
}

/**
 * Load list of all budgets
 */
async function loadBudgetHistory() {
    try {
        const data = await API.get('/api/budgets');
        if (!data.success) throw new Error(data.message);

        const tbody = document.getElementById('budgetHistoryTableBody');
        const emptyEl = document.getElementById('budgetHistoryEmpty');
        if (!tbody) return;

        tbody.innerHTML = '';

        if (!data.budgets || data.budgets.length === 0) {
            if (emptyEl) emptyEl.style.display = 'block';
            return;
        } else {
            if (emptyEl) emptyEl.style.display = 'none';
        }

        data.budgets.forEach(b => {
            const monthName = MONTH_NAMES[b.month - 1] || `Month ${b.month}`;
            const pct = b.percentage;

            let badgeHtml = '';
            if (b.status === 'exceeded') {
                badgeHtml = '<span class="badge badge-expense"><i class="fa-solid fa-triangle-exclamation"></i> Exceeded</span>';
            } else if (b.status === 'warning') {
                badgeHtml = '<span class="badge badge-warning"><i class="fa-solid fa-circle-exclamation"></i> Warning (80%+)</span>';
            } else {
                badgeHtml = '<span class="badge badge-income"><i class="fa-solid fa-check"></i> Safe</span>';
            }

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="font-weight: 600; color: var(--navy-900);">${monthName} ${b.year}</td>
                <td class="tabular-nums" style="font-weight: 600;">${formatCurrency(b.budget_amount)}</td>
                <td class="tabular-nums amount-expense">${formatCurrency(b.total_spent)}</td>
                <td class="tabular-nums" style="font-weight: 600; color: ${b.remaining < 0 ? 'var(--danger)' : 'var(--navy-900)'};">
                    ${formatCurrency(b.remaining)}
                </td>
                <td>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <div style="flex: 1; height: 6px; background-color: var(--bg-muted); border-radius: 9999px; overflow: hidden; min-width: 60px;">
                            <div style="width: ${Math.min(pct, 100)}%; height: 100%;" class="progress-bar-fill ${b.status}"></div>
                        </div>
                        <span style="font-size: 0.75rem; font-weight: 600;" class="tabular-nums">${pct}%</span>
                    </div>
                </td>
                <td>${badgeHtml}</td>
                <td style="text-align: right;">
                    <button class="btn-icon danger delete-budget-btn" data-id="${b.budget_id}" title="Delete Budget">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                </td>
            `;

            tr.querySelector('.delete-budget-btn').addEventListener('click', () => {
                openDeleteBudgetModal(b.budget_id);
            });

            tbody.appendChild(tr);
        });

    } catch (e) {
        console.error('Error loading budget history:', e);
    }
}

/**
 * Setup Set/Update Budget Modal
 */
function setupSetBudgetModal() {
    const modal = document.getElementById('setBudgetModal');
    const openBtns = document.querySelectorAll('.btn-open-set-budget');
    const closeBtn = document.getElementById('closeBudgetModalBtn');
    const cancelBtn = document.getElementById('cancelBudgetModalBtn');
    const form = document.getElementById('setBudgetForm');
    const modalMonthSelect = document.getElementById('modalBudgetMonth');
    const modalYearInput = document.getElementById('modalBudgetYear');

    if (modalMonthSelect) {
        modalMonthSelect.innerHTML = '';
        MONTH_NAMES.forEach((m, idx) => {
            const opt = document.createElement('option');
            opt.value = idx + 1;
            opt.textContent = m;
            modalMonthSelect.appendChild(opt);
        });
    }

    openBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            if (modalMonthSelect) modalMonthSelect.value = selectedMonth;
            if (modalYearInput) modalYearInput.value = selectedYear;
            if (modal) modal.classList.add('active');
        });
    });

    const closeModal = () => {
        if (modal) modal.classList.remove('active');
        if (form) form.reset();
    };

    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const amount = document.getElementById('modalBudgetAmount').value;
            const month = document.getElementById('modalBudgetMonth').value;
            const year = document.getElementById('modalBudgetYear').value;

            if (!amount || parseFloat(amount) <= 0) {
                showToast('Please enter a budget amount greater than 0', 'warning');
                return;
            }

            try {
                const res = await API.post('/api/budgets', { amount, month, year });
                if (res.success) {
                    showToast('Budget saved successfully!', 'success');
                    closeModal();
                    await loadCurrentBudget();
                    await loadBudgetHistory();
                }
            } catch (err) {
                showToast(err.message || 'Failed to save budget', 'error');
            }
        });
    }
}

/**
 * Setup Delete Budget Modal
 */
function setupDeleteBudgetModal() {
    const modal = document.getElementById('deleteBudgetModal');
    const cancelBtn = document.getElementById('cancelDeleteBudgetBtn');
    const confirmBtn = document.getElementById('confirmDeleteBudgetBtn');

    const closeModal = () => {
        if (modal) modal.classList.remove('active');
        currentDeleteBudgetId = null;
    };

    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
    }

    if (confirmBtn) {
        confirmBtn.addEventListener('click', async () => {
            if (!currentDeleteBudgetId) return;
            try {
                const res = await API.delete(`/api/budgets/${currentDeleteBudgetId}`);
                if (res.success) {
                    showToast('Budget record deleted', 'success');
                    closeModal();
                    await loadCurrentBudget();
                    await loadBudgetHistory();
                }
            } catch (err) {
                showToast(err.message || 'Failed to delete budget', 'error');
            }
        });
    }
}

function openDeleteBudgetModal(id) {
    currentDeleteBudgetId = id;
    const modal = document.getElementById('deleteBudgetModal');
    if (modal) modal.classList.add('active');
}

